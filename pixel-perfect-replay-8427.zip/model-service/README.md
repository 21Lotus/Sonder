# MindWell Model Service

Python inference service for the symptom-informed CatBoost model
(`mindwell_symptom_informed_model.joblib`). The bundle contains the trained
model, its fitted imputer, and the canonical 25-feature order — the service
uses all three exactly as stored. The model is never retrained, replaced, or
simulated.

## Run locally

```bash
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

## Endpoints

- `GET /health` — liveness probe.
- `POST /predict` — body: `{ "features": { "<feature>": <number|null>, ... } }`
  with exactly the 25 features stored in the bundle. Missing values are `null`
  and are imputed by the bundle's own imputer. Returns the predicted
  probability, the SHAP base value, and per-feature SHAP contributions
  (log-odds scale).

## Authentication

Set `MODEL_API_KEY` in the service environment to require
`Authorization: Bearer <key>` on `/predict`. Set the same value as the
`MODEL_API_KEY` secret in the MindWell app, and point the app's
`MODEL_API_URL` secret at this service's base URL (e.g. `https://your-host`).

## Deployment notes

- Host behind HTTPS on any Python-capable platform (a VM, container, or
  platform-as-a-service). The model file must ship with the service — never
  load model artifacts from untrusted sources.
- Keep the service private: it should only be reachable by the MindWell app
  backend, not directly by browsers.
