"""MindWell symptom-informed CatBoost model service.

Loads the trained model bundle (model, imputer, features) and exposes:
  GET  /health   — liveness probe
  POST /predict  — probability + SHAP contributions for the 25 NHANES predictors

Set MODEL_API_KEY to require `Authorization: Bearer <key>` on /predict.
"""

import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import shap
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

BUNDLE_PATH = Path(__file__).with_name("mindwell_symptom_informed_model.joblib")
API_KEY = os.environ.get("MODEL_API_KEY")

bundle = joblib.load(BUNDLE_PATH)
model, imputer, features = bundle["model"], bundle["imputer"], bundle["features"]
explainer = shap.TreeExplainer(model)

app = FastAPI(title="MindWell Model Service", docs_url=None, redoc_url=None)


class PredictionRequest(BaseModel):
    features: dict[str, float | None]


def check_auth(request: Request) -> None:
    if not API_KEY:
        return
    if request.headers.get("authorization") != f"Bearer {API_KEY}":
        raise HTTPException(401, detail="Unauthorized")


@app.get("/health")
def health():
    return {"status": "ok", "features": len(features)}


@app.post("/predict")
def predict(request: PredictionRequest, raw: Request):
    check_auth(raw)

    if set(request.features) != set(features):
        raise HTTPException(422, detail={
            "missing": sorted(set(features) - set(request.features)),
            "unexpected": sorted(set(request.features) - set(features)),
        })

    if any(v is not None and not np.isfinite(v) for v in request.features.values()):
        raise HTTPException(422, detail="Feature values must be finite")

    row = pd.DataFrame([{f: request.features[f] for f in features}], columns=features)
    x = pd.DataFrame(imputer.transform(row), columns=features)
    probability = float(model.predict_proba(x)[0, 1])
    explanation = explainer(x)

    contributions = [
        {
            "feature": f,
            "value": None if pd.isna(row.iloc[0][f]) else float(row.iloc[0][f]),
            "shap_value": float(explanation.values[0][i]),
        }
        for i, f in enumerate(features)
    ]
    contributions.sort(key=lambda item: abs(item["shap_value"]), reverse=True)

    return {
        "probability": probability,
        "target": "Remaining seven PHQ-9 symptom items sum to at least 8",
        "base_value": float(np.ravel(explanation.base_values)[0]),
        "shap_unit": "log_odds",
        "contributions": contributions,
    }
