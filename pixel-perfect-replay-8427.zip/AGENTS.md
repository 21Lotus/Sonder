<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- App state lives in `src/lib/store.tsx` (React context); persisted to localStorage only with user consent, else sessionStorage — health data must not leave the device by default.
- PHQ-9 scoring/severity logic lives only in `src/lib/phq9.ts` with tests in `phq9.test.ts` — single source of truth for clinical thresholds.
- ML model calls go through `src/lib/model.functions.ts` server functions (reads `MODEL_API_URL`/`MODEL_API_KEY`), wrapped by `src/services/modelApi.ts` — never call the model from the browser and never fabricate outputs.
- The trained CatBoost model runs in `model-service/` (FastAPI + joblib bundle, Python-only) because the app server is workerd; the app talks to it over HTTP with a bearer key. Keep scikit-learn pinned to the bundle's training version (1.6.1) or the unpickled imputer breaks.
- The 25 model predictors and their NHANES encodings live only in `src/lib/lifestyle.ts` (with tests in `lifestyle.test.ts`) — feature order must match the joblib bundle exactly; missing values stay null for the bundle's imputer.
