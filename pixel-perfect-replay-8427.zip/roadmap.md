# Roadmap — Symptom-Informed CatBoost Integration

- [x] Rename app MindWell → Sonder (name, logo, titles, PDF header, copy)
- [x] Model service: FastAPI app in `model-service/` loading uploaded joblib (model, imputer, features), `/predict` + `/health`, API-key auth
- [x] Expand lifestyle data to all 25 NHANES predictors with standard NHANES encodings, nullable
- [x] Update `model.functions.ts` + `modelApi.ts` to new contract (probability, base_value, shap contributions); MODEL_CARD ROC-AUC 0.9162
- [x] Rebuild Insights page: PHQ-9 results, exploratory model probability, interactive 25-feature SHAP chart with per-feature explanations, ROC-AUC 91.62%
- [x] Clinician report: include optional AI insights, clearly distinguished from reported symptoms
- [x] Tests for feature assembly (25-feature schema, PHQ-9 Q1/Q2 mapping, nullables)
- [x] Verify model service end-to-end locally (uvicorn + real /predict call)
