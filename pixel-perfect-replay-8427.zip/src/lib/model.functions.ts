import { createServerFn } from "@tanstack/react-start";
import { MODEL_FEATURE_NAMES, type ModelFeatures } from "./lifestyle";

export type ModelContribution = {
  feature: string;
  value: number | null;
  shap_value: number;
};

export type ModelResponse = {
  probability: number;
  target: string;
  base_value: number;
  shap_unit: string;
  contributions: ModelContribution[];
};

export type ModelResult =
  | { ok: true; data: ModelResponse }
  | { ok: false; reason: "not_configured" | "unavailable" | "invalid_response"; message: string };

function baseUrl() {
  const url = process.env["MODEL_API_URL"];
  return url ? url.replace(/\/$/, "") : null;
}

function authHeaders(): Record<string, string> {
  const key = process.env["MODEL_API_KEY"];
  return key ? { Authorization: `Bearer ${key}` } : {};
}

export const getModelStatus = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ status: "ready" | "unavailable" | "not_configured" }> => {
    const url = baseUrl();
    if (!url) return { status: "not_configured" };
    try {
      const r = await fetch(`${url}/health`, { headers: authHeaders() });
      return { status: r.ok ? "ready" : "unavailable" };
    } catch {
      return { status: "unavailable" };
    }
  },
);

// Every predictor must be present; values are nullable (imputed server-side).
function validFeatures(d: unknown): ModelFeatures {
  const o = d as Record<string, unknown>;
  if (!o || typeof o !== "object") throw new Error("Invalid features");
  for (const k of MODEL_FEATURE_NAMES) {
    const v = o[k];
    if (v !== null && (typeof v !== "number" || !Number.isFinite(v))) throw new Error(`Invalid ${k}`);
  }
  return o as unknown as ModelFeatures;
}

export const runPrediction = createServerFn({ method: "POST" })
  .inputValidator(validFeatures)
  .handler(async ({ data }): Promise<ModelResult> => {
    const url = baseUrl();
    if (!url) return { ok: false, reason: "not_configured", message: "The AI model is not configured." };
    try {
      const r = await fetch(`${url}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ features: data }),
      });
      if (!r.ok) return { ok: false, reason: "unavailable", message: `The model service responded with an error (${r.status}).` };
      const j = (await r.json()) as ModelResponse;
      if (
        typeof j?.probability !== "number" || j.probability < 0 || j.probability > 1 ||
        typeof j?.base_value !== "number" || !Array.isArray(j?.contributions) ||
        !j.contributions.every((c) => typeof c?.feature === "string" && typeof c?.shap_value === "number")
      )
        return { ok: false, reason: "invalid_response", message: "The model returned an unexpected response." };
      return { ok: true, data: j };
    } catch {
      return { ok: false, reason: "unavailable", message: "The model service could not be reached." };
    }
  });
