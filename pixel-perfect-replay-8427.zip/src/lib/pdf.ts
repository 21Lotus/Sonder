import type { AppState } from "./store";
import { PHQ9_ITEMS, isPositive, optionLabel, severityFor } from "./phq9";
import { EDUCATION_LEVELS, SEX_OPTIONS, FEATURE_META, incomePovertyRatio } from "./lifestyle";

export const DISCLAIMER =
  "This report summarizes self-reported information and exploratory machine-learning analysis. It is intended to support clinical discussion and does not constitute a diagnosis.";

export async function buildReportPdf(state: AppState) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const W = doc.internal.pageSize.getWidth();
  const M = 48;
  let y = 56;
  const teal: [number, number, number] = [16, 100, 112];
  const slate: [number, number, number] = [36, 51, 58];

  const ensure = (h: number) => { if (y + h > 740) { doc.addPage(); y = 56; } };
  const heading = (t: string) => {
    ensure(40); y += 12;
    doc.setFont("helvetica", "bold"); doc.setFontSize(12); doc.setTextColor(...teal); doc.text(t, M, y);
    y += 6; doc.setDrawColor(220, 230, 228); doc.line(M, y, W - M, y); y += 16;
    doc.setTextColor(...slate);
  };
  const para = (t: string, size = 10, bold = false) => {
    doc.setFont("helvetica", bold ? "bold" : "normal"); doc.setFontSize(size);
    const lines = doc.splitTextToSize(t, W - 2 * M);
    ensure(lines.length * size * 1.35); doc.text(lines, M, y); y += lines.length * size * 1.35 + 4;
  };
  const row = (k: string, v: string) => {
    ensure(16); doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(100, 115, 120); doc.text(k, M, y);
    doc.setTextColor(...slate); doc.text(v, M + 200, y); y += 16;
  };

  doc.setFont("helvetica", "bold"); doc.setFontSize(20); doc.setTextColor(...teal); doc.text("Sonder", M, y);
  doc.setFontSize(10); doc.setFont("helvetica", "normal"); doc.setTextColor(...slate);
  doc.text("Patient-reported mental health summary", W - M, y, { align: "right" }); y += 24;

  heading("Patient-Reported Mental Health Summary");
  const r = state.latest;
  if (state.patientName) row("Patient name", state.patientName);
  row("Report generated", new Date().toLocaleDateString(undefined, { dateStyle: "long" }));
  if (r) {
    row("Assessment date", new Date(r.completedAt).toLocaleDateString(undefined, { dateStyle: "long" }));
    row("PHQ-9 total score", `${r.score} / 27`);
    row("Symptom severity", severityFor(r.score));
    row("Screening outcome (cutoff >= 10)", isPositive(r.score) ? "Positive screen" : "Negative screen");
    if ((r.answers[8] ?? 0) > 0) { y += 4; para(`Item 9 (thoughts of death or self-harm) endorsed: "${optionLabel(r.answers[8])}". Crisis resources (988) were shown to the patient.`, 10, true); }

    heading("PHQ-9 Item Responses");
    PHQ9_ITEMS.forEach((q, i) => {
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5);
      const lines = doc.splitTextToSize(`${i + 1}. ${q}`, W - 2 * M - 170);
      ensure(lines.length * 13 + 4);
      doc.text(lines, M, y);
      doc.setFont("helvetica", "bold"); doc.text(`${r.answers[i]} - ${optionLabel(r.answers[i])}`, W - M, y, { align: "right" });
      y += lines.length * 13 + 5;
    });
  } else para("No PHQ-9 screening has been completed.");

  heading("Lifestyle Context (self-reported)");
  const l = state.lifestyle;
  const any = Object.values(l).some((v) => v != null);
  if (!any) para("No lifestyle information provided.");
  if (l.weekdaySleepHours != null) row("Average weekday sleep", `${l.weekdaySleepHours} hours`);
  if (l.sedentaryHours != null) row("Average daily sedentary time", `${l.sedentaryHours} hours`);
  if (l.age != null) row("Age", String(l.age));
  if (l.sex != null) row("Sex (NHANES coding)", SEX_OPTIONS.find((s) => s.value === l.sex)?.label ?? "");
  if (l.education != null) row("Education", EDUCATION_LEVELS.find((e) => e.value === l.education)?.label ?? "");
  if (l.income != null && l.householdSize) row("Income-to-poverty ratio (est.)", incomePovertyRatio(l.income, l.householdSize).toFixed(2));

  heading("AI-Assisted Insights (model-generated estimates)");
  const ai = state.aiInsight;
  if (ai) {
    para(`Exploratory model estimate: ${(ai.probability * 100).toFixed(0)}% probability that the remaining seven PHQ-9 items (3-9) sum to at least 8. Generated ${new Date(ai.computedAt).toLocaleDateString(undefined, { dateStyle: "long" })} from self-reported lifestyle, health, and PHQ-9 items 1-2.`, 10, true);
    para("This is a statistical estimate from a research model trained on NHANES population data. It is not a diagnosis, does not use the full PHQ-9 score, and should be interpreted only alongside clinical information.");
    const top = [...ai.contributions].sort((a, b) => Math.abs(b.shap_value) - Math.abs(a.shap_value)).slice(0, 5);
    if (top.length) {
      para("Largest model contributions (SHAP, log-odds scale):", 10, true);
      for (const c of top) {
        const label = FEATURE_META[c.feature]?.label ?? c.feature;
        row(label, `${c.shap_value >= 0 ? "+" : ""}${c.shap_value.toFixed(3)} (${c.shap_value >= 0 ? "raises" : "lowers"} estimate)`);
      }
    }
  } else {
    para("No machine-learning assessment was performed for this report.");
  }

  heading("Patient Notes");
  para(state.notes.trim() || "None provided.");

  heading("Limitations & Disclaimer");
  para("The PHQ-9 is a validated screening questionnaire, not a diagnostic instrument. Scores reflect the past two weeks as reported by the patient.", 9);
  para(DISCLAIMER, 9, true);

  return doc;
}
