export const ACTIVITIES = [
  { id: "myth", title: "Myth or Fact?", minutes: 4, description: "Test common beliefs about depression against the evidence." },
  { id: "brain", title: "Understanding the Brain", minutes: 5, description: "Explore brain systems involved in mood and stress." },
  { id: "sleep", title: "The Sleep and Mood Connection", minutes: 4, description: "See how sleep and mood relate in research." },
  { id: "support", title: "When Should You Seek Support?", minutes: 5, description: "Work through realistic scenarios and choices." },
] as const;

export type ActivityId = (typeof ACTIVITIES)[number]["id"];
