import { describe, expect, it } from "vitest";
import { isPositive, needsSafetySupport, scorePhq9, severityFor } from "./phq9";
import { incomePovertyRatio } from "./lifestyle";

describe("PHQ-9 scoring", () => {
  it("sums nine items, range 0–27", () => {
    expect(scorePhq9([0, 0, 0, 0, 0, 0, 0, 0, 0])).toBe(0);
    expect(scorePhq9([3, 3, 3, 3, 3, 3, 3, 3, 3])).toBe(27);
    expect(scorePhq9([1, 2, 0, 3, 1, 0, 2, 1, 0])).toBe(10);
  });
  it("rejects unanswered items", () => {
    expect(() => scorePhq9([0, 0, 0, 0, 0, 0, 0, 0, null])).toThrow();
  });
  it("uses established severity bands", () => {
    expect(severityFor(4)).toBe("Minimal");
    expect(severityFor(5)).toBe("Mild");
    expect(severityFor(9)).toBe("Mild");
    expect(severityFor(10)).toBe("Moderate");
    expect(severityFor(15)).toBe("Moderately severe");
    expect(severityFor(20)).toBe("Severe");
  });
  it("positive screen at 10 or higher", () => {
    expect(isPositive(9)).toBe(false);
    expect(isPositive(10)).toBe(true);
  });
  it("item 9 above 0 triggers safety support regardless of total", () => {
    expect(needsSafetySupport([0, 0, 0, 0, 0, 0, 0, 0, 1])).toBe(true);
    expect(needsSafetySupport([3, 3, 3, 3, 3, 3, 3, 3, 0])).toBe(false);
  });
});

describe("income-to-poverty ratio", () => {
  it("divides income by HHS guideline and caps at 5", () => {
    expect(incomePovertyRatio(30120, 1)).toBe(2);
    expect(incomePovertyRatio(1_000_000, 2)).toBe(5);
  });
});
