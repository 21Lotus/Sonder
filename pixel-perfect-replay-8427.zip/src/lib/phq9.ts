export const PHQ9_STEM =
  "Over the last 2 weeks, how often have you been bothered by any of the following problems?";

export const PHQ9_ITEMS = [
  "Little interest or pleasure in doing things",
  "Feeling down, depressed, or hopeless",
  "Trouble falling or staying asleep, or sleeping too much",
  "Feeling tired or having little energy",
  "Poor appetite or overeating",
  "Feeling bad about yourself — or that you are a failure or have let yourself or your family down",
  "Trouble concentrating on things, such as reading the newspaper or watching television",
  "Moving or speaking so slowly that other people could have noticed? Or the opposite — being so fidgety or restless that you have been moving around a lot more than usual",
  "Thoughts that you would be better off dead or of hurting yourself in some way",
] as const;

export const PHQ9_OPTIONS = [
  { value: 0, label: "Not at all" },
  { value: 1, label: "Several days" },
  { value: 2, label: "More than half the days" },
  { value: 3, label: "Nearly every day" },
] as const;

export const POSITIVE_THRESHOLD = 10;

export type Severity = "Minimal" | "Mild" | "Moderate" | "Moderately severe" | "Severe";

export function scorePhq9(answers: (number | null)[]): number {
  if (answers.length !== 9 || answers.some((a) => a === null || a < 0 || a > 3 || !Number.isInteger(a))) {
    throw new Error("PHQ-9 requires nine answers between 0 and 3");
  }
  return (answers as number[]).reduce((s, a) => s + a, 0);
}

export function severityFor(score: number): Severity {
  if (score <= 4) return "Minimal";
  if (score <= 9) return "Mild";
  if (score <= 14) return "Moderate";
  if (score <= 19) return "Moderately severe";
  return "Severe";
}

export function isPositive(score: number) {
  return score >= POSITIVE_THRESHOLD;
}

export function needsSafetySupport(answers: (number | null)[]) {
  return (answers[8] ?? 0) > 0;
}

export function interpretation(score: number): string {
  const sev = severityFor(score).toLowerCase();
  if (score <= 4)
    return "Your responses indicate minimal depressive symptoms. If anything is on your mind, it's always okay to talk with a healthcare professional.";
  if (score <= 9)
    return `Your responses indicate ${sev} depressive symptoms. Keep an eye on how you feel, and consider talking with a healthcare professional if symptoms continue.`;
  return `Your responses indicate ${sev} depressive symptoms. Consider discussing these results with a healthcare professional, who can provide a full evaluation.`;
}

export function optionLabel(v: number | undefined) {
  return PHQ9_OPTIONS.find((o) => o.value === v)?.label ?? "—";
}
