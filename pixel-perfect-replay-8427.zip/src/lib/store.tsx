import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { EMPTY_LIFESTYLE, type Lifestyle } from "./lifestyle";

export type ScreeningResult = {
  answers: number[];
  score: number;
  completedAt: string;
};

export type AiInsight = {
  probability: number;
  baseValue: number;
  target: string;
  contributions: { feature: string; value: number | null; shap_value: number }[];
  computedAt: string;
};

export type AppState = {
  onboarded: boolean;
  consentToSave: boolean;
  draftAnswers: (number | null)[];
  draftIndex: number;
  latest: ScreeningResult | null;
  history: ScreeningResult[];
  lifestyle: Lifestyle;
  patientName: string;
  notes: string;
  learn: Record<string, { completed: boolean; score?: number | undefined; total?: number | undefined }>;
  aiInsight: AiInsight | null;
};

const initial: AppState = {
  onboarded: false,
  consentToSave: false,
  draftAnswers: Array(9).fill(null),
  draftIndex: 0,
  latest: null,
  history: [],
  lifestyle: EMPTY_LIFESTYLE,
  patientName: "",
  notes: "",
  learn: {},
  aiInsight: null,
};

const KEY = "mindwell-state-v1";

type Ctx = {
  state: AppState;
  hydrated: boolean;
  update: (patch: Partial<AppState> | ((s: AppState) => Partial<AppState>)) => void;
  clearAll: () => void;
};

const StoreContext = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(initial);
  const [hydrated, setHydrated] = useState(false);
  const first = useRef(true);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY) ?? sessionStorage.getItem(KEY);
      if (raw) setState({ ...initial, ...JSON.parse(raw) });
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    if (first.current) { first.current = false; return; }
    const raw = JSON.stringify(state);
    // Persist across visits only with explicit consent; otherwise this browser session only.
    if (state.consentToSave) {
      localStorage.setItem(KEY, raw);
      sessionStorage.removeItem(KEY);
    } else {
      sessionStorage.setItem(KEY, raw);
      localStorage.removeItem(KEY);
    }
  }, [state, hydrated]);

  const update = useCallback<Ctx["update"]>((patch) => {
    setState((s) => ({ ...s, ...(typeof patch === "function" ? patch(s) : patch) }));
  }, []);

  const clearAll = useCallback(() => {
    localStorage.removeItem(KEY);
    sessionStorage.removeItem(KEY);
    setState({ ...initial, onboarded: true });
  }, []);

  return <StoreContext.Provider value={{ state, hydrated, update, clearAll }}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const c = useContext(StoreContext);
  if (!c) throw new Error("useStore outside provider");
  return c;
}
