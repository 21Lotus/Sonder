// 2024 HHS poverty guidelines, 48 contiguous states & DC.
export const POVERTY_BASE = 15060;
export const POVERTY_PER_PERSON = 5380;
export const POVERTY_YEAR = 2024;

export function incomePovertyRatio(annualIncome: number, householdSize: number): number {
  const guideline = POVERTY_BASE + POVERTY_PER_PERSON * (householdSize - 1);
  const r = annualIncome / guideline;
  return Math.round(Math.min(5, Math.max(0, r)) * 100) / 100; // NHANES INDFMPIR is top-coded at 5
}

// NHANES DMDEDUC2 coding (adults 20+)
export const EDUCATION_LEVELS = [
  { value: 1, label: "Less than 9th grade" },
  { value: 2, label: "9th–11th grade (no diploma)" },
  { value: 3, label: "High school graduate / GED" },
  { value: 4, label: "Some college or associate degree" },
  { value: 5, label: "College graduate or above" },
];

// NHANES RIAGENDR coding
export const SEX_OPTIONS = [
  { value: 1, label: "Male" },
  { value: 2, label: "Female" },
];

// NHANES yes/no coding used by BPQ020, DIQ010, MCQ010, MCQ160*, MCQ220, HIQ011, SMQ020
export const YES_NO = [
  { value: 1, label: "Yes" },
  { value: 2, label: "No" },
];

// NHANES SMQ040 coding
export const SMOKING_STATUS = [
  { value: 1, label: "Every day" },
  { value: 2, label: "Some days" },
  { value: 3, label: "Not at all" },
];

// NHANES DMDMARTL coding
export const MARITAL_STATUS = [
  { value: 1, label: "Married" },
  { value: 2, label: "Widowed" },
  { value: 3, label: "Divorced" },
  { value: 4, label: "Separated" },
  { value: 5, label: "Never married" },
  { value: 6, label: "Living with partner" },
];

// NHANES HUQ030 coding
export const USUAL_PLACE = [
  { value: 1, label: "Yes" },
  { value: 3, label: "Yes, more than one place" },
  { value: 2, label: "No" },
];

// NHANES HSD010 coding
export const GENERAL_HEALTH = [
  { value: 1, label: "Excellent" },
  { value: 2, label: "Very good" },
  { value: 3, label: "Good" },
  { value: 4, label: "Fair" },
  { value: 5, label: "Poor" },
];

export type Lifestyle = {
  age: number | null;
  sex: number | null;
  education: number | null;
  income: number | null;
  householdSize: number | null;
  weekdaySleepHours: number | null;
  sedentaryHours: number | null;
  hypertension: number | null;
  diabetes: number | null;
  asthma: number | null;
  heartFailure: number | null;
  coronaryHeartDisease: number | null;
  stroke: number | null;
  everSmoked100: number | null;
  smokingStatus: number | null;
  maritalStatus: number | null;
  healthcareUsualPlace: number | null;
  healthInsurance: number | null;
  generalHealthRating: number | null;
  arthritisHistory: number | null;
  heartAttackHistory: number | null;
  liverConditionHistory: number | null;
  thyroidConditionHistory: number | null;
  cancerHistory: number | null;
};

export const EMPTY_LIFESTYLE: Lifestyle = {
  age: null,
  sex: null,
  education: null,
  income: null,
  householdSize: null,
  weekdaySleepHours: null,
  sedentaryHours: null,
  hypertension: null,
  diabetes: null,
  asthma: null,
  heartFailure: null,
  coronaryHeartDisease: null,
  stroke: null,
  everSmoked100: null,
  smokingStatus: null,
  maritalStatus: null,
  healthcareUsualPlace: null,
  healthInsurance: null,
  generalHealthRating: null,
  arthritisHistory: null,
  heartAttackHistory: null,
  liverConditionHistory: null,
  thyroidConditionHistory: null,
  cancerHistory: null,
};

// The 25 predictors in the exact order stored in the trained model artifact.
// Values are nullable: missing answers are imputed by the model's own imputer.
export type ModelFeatures = {
  age: number | null;
  sex: number | null;
  income_poverty_ratio: number | null;
  education: number | null;
  weekday_sleep_hours: number | null;
  sedentary_hours: number | null;
  hypertension: number | null;
  diabetes: number | null;
  asthma: number | null;
  heart_failure: number | null;
  coronary_heart_disease: number | null;
  stroke: number | null;
  ever_smoked_100: number | null;
  smoking_status: number | null;
  marital_status: number | null;
  healthcare_usual_place: number | null;
  health_insurance: number | null;
  general_health_rating: number | null;
  arthritis_history: number | null;
  heart_attack_history: number | null;
  liver_condition_history: number | null;
  thyroid_condition_history: number | null;
  cancer_history: number | null;
  loss_of_interest: number | null;
  depressed_mood_hopelessness: number | null;
};

export const MODEL_FEATURE_NAMES = [
  "age", "sex", "income_poverty_ratio", "education",
  "weekday_sleep_hours", "sedentary_hours", "hypertension",
  "diabetes", "asthma", "heart_failure",
  "coronary_heart_disease", "stroke", "ever_smoked_100",
  "smoking_status", "marital_status",
  "healthcare_usual_place", "health_insurance",
  "general_health_rating", "arthritis_history",
  "heart_attack_history", "liver_condition_history",
  "thyroid_condition_history", "cancer_history",
  "loss_of_interest", "depressed_mood_hopelessness",
] as const;

// Assemble the 25 model predictors from lifestyle answers plus PHQ-9 items 1
// and 2 (loss_of_interest, depressed_mood_hopelessness). Missing answers stay
// null and are imputed server-side by the model bundle's own imputer.
export function toModelFeatures(l: Lifestyle, phq9Answers?: (number | null)[] | null): ModelFeatures {
  return {
    age: l.age,
    sex: l.sex,
    income_poverty_ratio:
      l.income != null && l.householdSize != null && l.householdSize > 0
        ? incomePovertyRatio(l.income, l.householdSize)
        : null,
    education: l.education,
    weekday_sleep_hours: l.weekdaySleepHours,
    sedentary_hours: l.sedentaryHours,
    hypertension: l.hypertension,
    diabetes: l.diabetes,
    asthma: l.asthma,
    heart_failure: l.heartFailure,
    coronary_heart_disease: l.coronaryHeartDisease,
    stroke: l.stroke,
    ever_smoked_100: l.everSmoked100,
    smoking_status: l.smokingStatus,
    marital_status: l.maritalStatus,
    healthcare_usual_place: l.healthcareUsualPlace,
    health_insurance: l.healthInsurance,
    general_health_rating: l.generalHealthRating,
    arthritis_history: l.arthritisHistory,
    heart_attack_history: l.heartAttackHistory,
    liver_condition_history: l.liverConditionHistory,
    thyroid_condition_history: l.thyroidConditionHistory,
    cancer_history: l.cancerHistory,
    loss_of_interest: phq9Answers?.[0] ?? null,
    depressed_mood_hopelessness: phq9Answers?.[1] ?? null,
  };
}

export function countProvidedFeatures(f: ModelFeatures): number {
  return Object.values(f).filter((v) => v != null).length;
}

// Display names and plain-language, non-causal explanations for each predictor.
export const FEATURE_META: Record<string, { label: string; explanation: string }> = {
  age: { label: "Age", explanation: "Age is associated with differences in reported symptom patterns across the population." },
  sex: { label: "Sex", explanation: "Reported symptom patterns differ between males and females in the survey data." },
  income_poverty_ratio: { label: "Income-to-poverty ratio", explanation: "Lower income relative to the poverty line is associated with higher reported symptom burden in the data." },
  education: { label: "Education level", explanation: "Education level is associated with differences in reported symptom burden in the data." },
  weekday_sleep_hours: { label: "Weekday sleep", explanation: "Both short and long sleep duration are associated with differences in reported symptoms." },
  sedentary_hours: { label: "Sedentary time", explanation: "More daily sitting time is associated with differences in reported symptom burden." },
  hypertension: { label: "Hypertension", explanation: "A history of high blood pressure is associated with differences in reported symptoms." },
  diabetes: { label: "Diabetes", explanation: "A diabetes diagnosis is associated with differences in reported symptom burden." },
  asthma: { label: "Asthma", explanation: "A history of asthma is associated with differences in reported symptoms." },
  heart_failure: { label: "Heart failure", explanation: "A history of heart failure is associated with differences in reported symptom burden." },
  coronary_heart_disease: { label: "Coronary heart disease", explanation: "A history of coronary heart disease is associated with differences in reported symptoms." },
  stroke: { label: "Stroke", explanation: "A history of stroke is associated with differences in reported symptom burden." },
  ever_smoked_100: { label: "Ever smoked 100 cigarettes", explanation: "Lifetime smoking history is associated with differences in reported symptoms." },
  smoking_status: { label: "Current smoking", explanation: "Current smoking frequency is associated with differences in reported symptom burden." },
  marital_status: { label: "Marital status", explanation: "Marital status is associated with differences in reported symptoms in the data." },
  healthcare_usual_place: { label: "Usual place for healthcare", explanation: "Having a usual source of care is associated with differences in reported symptom patterns." },
  health_insurance: { label: "Health insurance", explanation: "Insurance coverage is associated with differences in reported symptom patterns." },
  general_health_rating: { label: "General health rating", explanation: "Self-rated overall health is associated with reported symptom burden." },
  arthritis_history: { label: "Arthritis history", explanation: "A history of arthritis is associated with differences in reported symptoms." },
  heart_attack_history: { label: "Heart attack history", explanation: "A history of heart attack is associated with differences in reported symptom burden." },
  liver_condition_history: { label: "Liver condition history", explanation: "A history of liver conditions is associated with differences in reported symptoms." },
  thyroid_condition_history: { label: "Thyroid condition history", explanation: "A history of thyroid conditions is associated with differences in reported symptoms." },
  cancer_history: { label: "Cancer history", explanation: "A history of cancer is associated with differences in reported symptom burden." },
  loss_of_interest: { label: "Loss of interest (PHQ-9 item 1)", explanation: "Your answer to PHQ-9 item 1 — little interest or pleasure in doing things." },
  depressed_mood_hopelessness: { label: "Depressed mood (PHQ-9 item 2)", explanation: "Your answer to PHQ-9 item 2 — feeling down, depressed, or hopeless." },
};
