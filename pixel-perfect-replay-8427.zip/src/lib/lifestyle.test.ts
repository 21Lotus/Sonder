import { describe, expect, it } from "vitest";
import { EMPTY_LIFESTYLE, MODEL_FEATURE_NAMES, countProvidedFeatures, incomePovertyRatio, toModelFeatures, type Lifestyle } from "./lifestyle";

const full: Lifestyle = {
  age: 45, sex: 2, education: 4, income: 40000, householdSize: 3,
  weekdaySleepHours: 6.5, sedentaryHours: 9,
  hypertension: 2, diabetes: 2, asthma: 2, heartFailure: 2, coronaryHeartDisease: 2, stroke: 2,
  everSmoked100: 1, smokingStatus: 3, maritalStatus: 1,
  healthcareUsualPlace: 1, healthInsurance: 1, generalHealthRating: 3,
  arthritisHistory: 2, heartAttackHistory: 2, liverConditionHistory: 2, thyroidConditionHistory: 2, cancerHistory: 2,
};

describe("toModelFeatures", () => {
  it("produces exactly the 25 predictors in the model artifact's order", () => {
    const f = toModelFeatures(full, [2, 1, 0, 0, 0, 0, 0, 0, 0]);
    expect(Object.keys(f)).toEqual([...MODEL_FEATURE_NAMES]);
    expect(MODEL_FEATURE_NAMES).toHaveLength(25);
  });

  it("maps PHQ-9 items 1 and 2 to the last two predictors", () => {
    const f = toModelFeatures(full, [2, 1, 0, 0, 0, 0, 0, 0, 0]);
    expect(f.loss_of_interest).toBe(2);
    expect(f.depressed_mood_hopelessness).toBe(1);
  });

  it("leaves symptom predictors null without a screening", () => {
    const f = toModelFeatures(full, null);
    expect(f.loss_of_interest).toBeNull();
    expect(f.depressed_mood_hopelessness).toBeNull();
  });

  it("keeps missing answers null for server-side imputation", () => {
    const f = toModelFeatures(EMPTY_LIFESTYLE, null);
    expect(Object.values(f).every((v) => v === null)).toBe(true);
    expect(countProvidedFeatures(f)).toBe(0);
  });

  it("computes the income-to-poverty ratio from income and household size", () => {
    const f = toModelFeatures(full, null);
    expect(f.income_poverty_ratio).toBe(incomePovertyRatio(40000, 3));
  });

  it("leaves the ratio null when income or household size is missing", () => {
    expect(toModelFeatures({ ...full, income: null }, null).income_poverty_ratio).toBeNull();
    expect(toModelFeatures({ ...full, householdSize: null }, null).income_poverty_ratio).toBeNull();
  });

  it("counts provided inputs including PHQ-9 items", () => {
    const f = toModelFeatures(full, [0, 0, 0, 0, 0, 0, 0, 0, 0]);
    expect(countProvidedFeatures(f)).toBe(25);
  });
});
