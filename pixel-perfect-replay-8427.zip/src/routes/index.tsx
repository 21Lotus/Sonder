import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ClipboardList, Sparkles, Stethoscope, ShieldCheck, ArrowRight, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Logo } from "@/components/Logo";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sonder — Understand your mind. Empower your care." },
      { name: "description", content: "Evidence-based depression screening, interactive education, and AI-assisted insights to support conversations with healthcare professionals." },
      { property: "og:title", content: "Sonder — Understand your mind. Empower your care." },
      { property: "og:description", content: "Evidence-based screening, education, and explainable AI insights for better clinical conversations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Welcome,
});

const SLIDES = [
  { icon: ClipboardList, title: "Screen Your Symptoms", body: "Understand your recent emotional well-being using a standardized mental health questionnaire.", tone: "bg-secondary text-primary" },
  { icon: Sparkles, title: "Explore Your Factors", body: "Discover how sleep, lifestyle, and other characteristics relate to patterns observed in population-level research.", tone: "bg-lavender-soft text-lavender" },
  { icon: Stethoscope, title: "Partner With Your Clinician", body: "Turn your screening results and insights into a report that can support a professional evaluation.", tone: "bg-positive-soft text-positive" },
];

function Welcome() {
  const { update } = useStore();
  const navigate = useNavigate();
  const [step, setStep] = useState(-1); // -1 welcome, 0..2 slides, 3 privacy
  const [consent, setConsent] = useState(false);

  const finish = (to: "/screening" | "/learn") => {
    update({ onboarded: true, consentToSave: consent });
    navigate({ to });
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        <button onClick={() => finish("/learn")} className="text-sm font-medium text-muted-foreground hover:text-foreground">
          Explore learning without screening
        </button>
      </header>

      <main className="mx-auto grid w-full max-w-6xl flex-1 items-center gap-10 px-5 pb-12 lg:grid-cols-2">
        {step === -1 && (
          <section className="fade-up">
            <p className="eyebrow">Screening · Insights · Education</p>
            <h1 className="mt-3 text-4xl font-semibold leading-[1.08] sm:text-5xl lg:text-6xl">
              Understand your mind.<br /><span className="text-primary">Empower your care.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground">
              Explore your mental health through evidence-based screening, interactive education, and AI-assisted
              insights designed to support conversations with healthcare professionals.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" className="h-12 px-6" onClick={() => setStep(3)}>Get Started <ArrowRight /></Button>
              <Button size="lg" variant="outline" className="h-12 px-6" onClick={() => setStep(0)}>How Sonder Works</Button>
            </div>
            <p className="mt-6 text-xs text-muted-foreground">Sonder supports clinical care — it does not diagnose or replace a clinician.</p>
          </section>
        )}

        {step >= 0 && step <= 2 && (
          <section key={step} className="fade-up">
            <p className="eyebrow">Step {step + 1} of 3</p>
            {(() => { const S = SLIDES[step]!; return (
              <>
                <div className={`mt-4 grid size-14 place-items-center rounded-2xl ${S.tone}`}><S.icon className="size-7" aria-hidden /></div>
                <h1 className="mt-5 text-3xl font-semibold sm:text-4xl">{S.title}</h1>
                <p className="mt-3 max-w-lg text-lg text-muted-foreground">{S.body}</p>
              </>
            ); })()}
            <div className="mt-6 flex gap-1.5" aria-hidden>
              {SLIDES.map((_, i) => <span key={i} className={`h-1.5 rounded-full transition-all ${i === step ? "w-8 bg-primary" : "w-3 bg-border"}`} />)}
            </div>
            <div className="mt-8 flex gap-3">
              <Button variant="ghost" onClick={() => setStep(step - 1)}><ArrowLeft /> Back</Button>
              <Button onClick={() => setStep(step + 1)}>{step === 2 ? "Continue" : "Next"} <ArrowRight /></Button>
            </div>
          </section>
        )}

        {step === 3 && (
          <section className="fade-up">
            <div className="grid size-14 place-items-center rounded-2xl bg-secondary text-primary"><ShieldCheck className="size-7" aria-hidden /></div>
            <h1 className="mt-5 text-3xl font-semibold">Your privacy comes first</h1>
            <ul className="mt-4 space-y-2.5 text-muted-foreground">
              <li>• No account is required. Your answers stay on this device.</li>
              <li>• We don't ask for your name, email, or other identifiers to screen.</li>
              <li>• No advertising trackers. Health answers are never placed in URLs or analytics.</li>
              <li>• If AI analysis is connected, only lifestyle numbers are sent for analysis — not your PHQ-9 answers or name.</li>
              <li>• You can export or delete everything at any time in Settings.</li>
            </ul>
            <label className="mt-6 flex cursor-pointer items-start gap-3 rounded-xl border bg-card p-4">
              <Checkbox checked={consent} onCheckedChange={(v) => setConsent(v === true)} className="mt-0.5" />
              <span className="text-sm">
                <strong className="block">Remember my responses on this device</strong>
                <span className="text-muted-foreground">Optional. If unchecked, your answers are kept only until you close this browser tab.</span>
              </span>
            </label>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button variant="ghost" onClick={() => setStep(-1)}><ArrowLeft /> Back</Button>
              <Button size="lg" className="h-12 px-6" onClick={() => finish("/screening")}>Begin screening <ArrowRight /></Button>
            </div>
          </section>
        )}

        <HeroVisual />
      </main>
    </div>
  );
}

function HeroVisual() {
  return (
    <div className="relative hidden aspect-square w-full max-w-lg justify-self-center lg:block" aria-hidden>
      <div className="absolute inset-8 rounded-full bg-secondary" />
      <div className="absolute inset-24 rounded-full bg-lavender-soft" />
      <div className="absolute left-4 top-16 w-60 card-surface p-4 shadow-lift fade-up">
        <p className="eyebrow">PHQ-9 screening</p>
        <p className="mt-2 text-3xl font-semibold">7<span className="text-base text-muted-foreground"> / 27</span></p>
        <div className="mt-3 h-2 rounded-full bg-muted"><div className="h-2 w-1/4 rounded-full bg-primary" /></div>
        <p className="mt-2 text-xs text-muted-foreground">Example only</p>
      </div>
      <div className="absolute bottom-20 right-2 w-64 card-surface p-4 shadow-lift fade-up [animation-delay:150ms]">
        <p className="eyebrow">Explainable factors</p>
        {[70, 45, 28].map((w, i) => (
          <div key={i} className="mt-2.5 flex items-center gap-2">
            <span className="h-2 w-16 rounded bg-muted" />
            <span className={`h-2 rounded ${i === 1 ? "bg-lavender" : "bg-primary"}`} style={{ width: `${w}%` }} />
          </div>
        ))}
      </div>
      <div className="absolute bottom-6 left-16 flex items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm shadow-card fade-up [animation-delay:300ms]">
        <Stethoscope className="size-4 text-primary" /> Report ready for your doctor
      </div>
    </div>
  );
}
