import { createFileRoute } from "@tanstack/react-router";
import { Download, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useStore } from "@/lib/store";
import { severityFor } from "@/lib/phq9";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings & Privacy — Sonder" },
      { name: "description", content: "Manage storage consent, export, or delete your Sonder data." },
      { property: "og:title", content: "Settings & Privacy — Sonder" },
      { property: "og:description", content: "Manage consent, export, and delete your data." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const { state, update, clearAll } = useStore();
  const exportData = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "sonder-data.json"; a.click();
  };
  return (
    <AppShell title="Settings & Privacy" subtitle="Your data stays on this device. You're in control of it.">
      <div className="max-w-2xl space-y-5">
        <section className="card-surface flex items-start justify-between gap-4 p-6">
          <div>
            <h2 className="font-semibold">Remember my responses on this device</h2>
            <p className="mt-1 text-sm text-muted-foreground">When off, data is cleared when you close this tab.</p>
          </div>
          <Switch checked={state.consentToSave} onCheckedChange={(v) => update({ consentToSave: v })} aria-label="Remember my responses" />
        </section>

        <section className="card-surface p-6">
          <h2 className="font-semibold">Screening history</h2>
          {state.history.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">No screenings yet.</p> : (
            <ul className="mt-3 divide-y text-sm">
              {state.history.map((h) => (
                <li key={h.completedAt} className="flex justify-between py-2">
                  <span>{new Date(h.completedAt).toLocaleString()}</span><span className="font-medium">{h.score}/27 · {severityFor(h.score)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card-surface space-y-3 p-6">
          <h2 className="font-semibold">Your data</h2>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={exportData}><Download /> Export my data</Button>
            <AlertDialog>
              <AlertDialogTrigger asChild><Button variant="destructive"><Trash2 /> Delete all data</Button></AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete all your Sonder data?</AlertDialogTitle>
                  <AlertDialogDescription>This removes screenings, lifestyle answers, notes, and learning progress from this device. It can't be undone.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => { clearAll(); toast.success("All data deleted"); }}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </section>

        <section className="card-surface p-6 text-sm text-muted-foreground">
          <h2 className="font-semibold text-foreground">About Sonder</h2>
          <p className="mt-2">Sonder supports, but never replaces, licensed clinicians. It is not a diagnostic device and has not been reviewed for HIPAA compliance. In a crisis, call or text 988 (US) or call 911.</p>
        </section>
      </div>
    </AppShell>
  );
}
