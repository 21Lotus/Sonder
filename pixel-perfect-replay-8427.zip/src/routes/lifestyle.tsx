import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Info } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";
import {
  EDUCATION_LEVELS, SEX_OPTIONS, YES_NO, SMOKING_STATUS, MARITAL_STATUS, USUAL_PLACE, GENERAL_HEALTH,
  incomePovertyRatio, toModelFeatures, countProvidedFeatures, POVERTY_YEAR, type Lifestyle,
} from "@/lib/lifestyle";

export const Route = createFileRoute("/lifestyle")({
  head: () => ({
    meta: [
      { title: "Lifestyle Assessment — Sonder" },
      { name: "description", content: "Optional lifestyle and demographic questions used for exploratory AI analysis." },
      { property: "og:title", content: "Lifestyle Assessment — Sonder" },
      { property: "og:description", content: "Optional lifestyle questions for exploratory, research-based analysis." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LifestyleAssessment,
});

type Field = keyof Lifestyle;
const RANGES: Partial<Record<Field, [number, number, string]>> = {
  age: [20, 80, "Age must be between 20 and 80 (the model's NHANES adult range)."],
  income: [0, 10_000_000, "Enter an annual amount of 0 or more."],
  householdSize: [1, 20, "Household size must be between 1 and 20."],
  weekdaySleepHours: [2, 14, "Enter between 2 and 14 hours."],
  sedentaryHours: [0, 20, "Enter between 0 and 20 hours."],
};

const CONDITIONS: { field: Field; label: string }[] = [
  { field: "hypertension", label: "High blood pressure (hypertension)" },
  { field: "diabetes", label: "Diabetes" },
  { field: "asthma", label: "Asthma" },
  { field: "heartFailure", label: "Congestive heart failure" },
  { field: "coronaryHeartDisease", label: "Coronary heart disease" },
  { field: "stroke", label: "Stroke" },
  { field: "arthritisHistory", label: "Arthritis" },
  { field: "heartAttackHistory", label: "Heart attack" },
  { field: "liverConditionHistory", label: "Liver condition" },
  { field: "thyroidConditionHistory", label: "Thyroid condition" },
  { field: "cancerHistory", label: "Cancer (any kind)" },
];

function LifestyleAssessment() {
  const { state, update } = useStore();
  const navigate = useNavigate();
  const [f, setF] = useState<Lifestyle>({ ...state.lifestyle });
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});

  const set = (k: Field, raw: string) => setF((p) => ({ ...p, [k]: raw === "" ? null : Number(raw) }));

  const save = () => {
    const e: typeof errors = {};
    for (const [k, r] of Object.entries(RANGES) as [Field, [number, number, string]][]) {
      const v = f[k];
      if (v != null && (Number.isNaN(v) || v < r[0] || v > r[1])) e[k] = r[2];
    }
    setErrors(e);
    if (Object.keys(e).length) return;
    update({ lifestyle: f });
    navigate({ to: "/insights" });
  };

  const pir = f.income != null && f.householdSize ? incomePovertyRatio(f.income, f.householdSize) : null;
  const provided = countProvidedFeatures(toModelFeatures(f, state.latest?.answers));

  return (
    <AppShell title="Lifestyle & health context" subtitle="Optional. These answers are used only for exploratory AI analysis — separate from your PHQ-9 score.">
      <form className="max-w-2xl space-y-5" onSubmit={(e) => { e.preventDefault(); save(); }} noValidate>
        <section className="card-surface space-y-5 p-6">
          <h2 className="font-semibold">Daily habits</h2>
          <NumberField id="weekdaySleepHours" label="Average weekday sleep (hours per night)" step="0.5" value={f.weekdaySleepHours} onChange={set} error={errors.weekdaySleepHours} />
          <NumberField id="sedentaryHours" label="Average daily sedentary time (hours)" hint="Time spent sitting or reclining — at work, commuting, screens — excluding sleep." step="0.5" value={f.sedentaryHours} onChange={set} error={errors.sedentaryHours} />
        </section>

        <section className="card-surface space-y-5 p-6">
          <h2 className="font-semibold">About you</h2>
          <NumberField id="age" label="Age (years)" value={f.age} onChange={set} error={errors.age} />
          <SelectField id="sex" label="Sex (as recorded in the NHANES dataset)" options={SEX_OPTIONS} value={f.sex} onChange={set}
            hint="NHANES records only two categories. If neither describes you, you can skip — the model may not represent you accurately." />
          <SelectField id="education" label="Highest education completed" options={EDUCATION_LEVELS} value={f.education} onChange={set} />
          <SelectField id="maritalStatus" label="Marital status" options={MARITAL_STATUS} value={f.maritalStatus} onChange={set} />
        </section>

        <section className="card-surface space-y-5 p-6">
          <h2 className="font-semibold">Household income</h2>
          <p className="text-sm text-muted-foreground">The model uses the <strong>income-to-poverty ratio</strong>: your household income divided by the federal poverty guideline for your household size. Only the ratio is sent for analysis.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <NumberField id="income" label="Annual household income (USD)" value={f.income} onChange={set} error={errors.income} />
            <NumberField id="householdSize" label="People in household" value={f.householdSize} onChange={set} error={errors.householdSize} />
          </div>
          {pir != null && <p className="rounded-lg bg-secondary px-3 py-2 text-sm">Estimated ratio: <strong>{pir.toFixed(2)}</strong> <span className="text-muted-foreground">({POVERTY_YEAR} HHS guidelines, contiguous US; capped at 5)</span></p>}
        </section>

        <section className="card-surface space-y-5 p-6">
          <h2 className="font-semibold">Health conditions</h2>
          <p className="text-sm text-muted-foreground">Has a doctor or other health professional ever told you that you had any of the following?</p>
          <div className="grid gap-4 sm:grid-cols-2">
            {CONDITIONS.map((c) => <SelectField key={c.field} id={c.field} label={c.label} options={YES_NO} value={f[c.field]} onChange={set} />)}
          </div>
        </section>

        <section className="card-surface space-y-5 p-6">
          <h2 className="font-semibold">Smoking</h2>
          <SelectField id="everSmoked100" label="Have you smoked at least 100 cigarettes in your entire life?" options={YES_NO} value={f.everSmoked100} onChange={set} />
          <SelectField id="smokingStatus" label="Do you now smoke cigarettes?" options={SMOKING_STATUS} value={f.smokingStatus} onChange={set} />
        </section>

        <section className="card-surface space-y-5 p-6">
          <h2 className="font-semibold">Healthcare access</h2>
          <SelectField id="healthcareUsualPlace" label="Is there a place you usually go when you are sick or need health advice?" options={USUAL_PLACE} value={f.healthcareUsualPlace} onChange={set} />
          <SelectField id="healthInsurance" label="Are you covered by health insurance?" options={YES_NO} value={f.healthInsurance} onChange={set} />
          <SelectField id="generalHealthRating" label="How would you rate your general health?" options={GENERAL_HEALTH} value={f.generalHealthRating} onChange={set} />
        </section>

        <p className="flex gap-2 rounded-xl bg-muted p-4 text-sm text-muted-foreground">
          <Info className="mt-0.5 size-4 shrink-0" aria-hidden />
          Every field is optional — the model estimates missing answers statistically. You've provided {provided} of 25 inputs so far (two more come from your PHQ-9 screening). More complete answers give more reliable insights.
        </p>
        <div className="flex gap-2">
          <Button type="submit" size="lg" className="h-12">Save and continue</Button>
          <Button type="button" variant="ghost" size="lg" className="h-12" onClick={() => navigate({ to: "/overview" })}>Skip for now</Button>
        </div>
      </form>
    </AppShell>
  );
}

function NumberField({ id, label, hint, value, onChange, error, step }: {
  id: Field; label: string; hint?: string | undefined; value: number | null; onChange: (k: Field, v: string) => void; error?: string | undefined; step?: string | undefined;
}) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} type="number" inputMode="decimal" step={step ?? "1"} className="mt-1.5 h-11 bg-card" value={value ?? ""}
        onChange={(e) => onChange(id, e.target.value)} aria-invalid={!!error} aria-describedby={error ? `${id}-err` : undefined} />
      {hint && <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p>}
      {error && <p id={`${id}-err`} className="mt-1.5 text-sm text-destructive">{error}</p>}
    </div>
  );
}

function SelectField({ id, label, hint, options, value, onChange }: {
  id: Field; label: string; hint?: string | undefined; options: { value: number; label: string }[]; value: number | null; onChange: (k: Field, v: string) => void;
}) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <select id={id} className="mt-1.5 h-11 w-full rounded-md border border-input bg-card px-3" value={value ?? ""} onChange={(e) => onChange(id, e.target.value)}>
        <option value="">Prefer not to say</option>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      {hint && <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
