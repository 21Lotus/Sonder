import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Download, Printer, Share2, Mail, ArrowRight, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/store";
import { PHQ9_ITEMS, isPositive, optionLabel, severityFor } from "@/lib/phq9";
import { EDUCATION_LEVELS, incomePovertyRatio } from "@/lib/lifestyle";
import { buildReportPdf, DISCLAIMER } from "@/lib/pdf";

export const Route = createFileRoute("/doctor")({
  head: () => ({
    meta: [
      { title: "For Your Doctor — Sonder" },
      { name: "description", content: "Generate a clinician-friendly PHQ-9 report as a PDF to download, print, or share." },
      { property: "og:title", content: "For Your Doctor — Sonder" },
      { property: "og:description", content: "Create a clinician-friendly PDF report of your screening." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Doctor,
});

function Doctor() {
  const { state, update } = useStore();
  const [busy, setBusy] = useState<string | null>(null);
  const r = state.latest;
  const l = state.lifestyle;
  const fileName = `Sonder-report-${new Date().toISOString().slice(0, 10)}.pdf`;

  const withPdf = async (kind: string, fn: (blob: Blob, doc: Awaited<ReturnType<typeof buildReportPdf>>) => Promise<void> | void) => {
    setBusy(kind);
    try { const doc = await buildReportPdf(state); await fn(doc.output("blob"), doc); }
    catch (e) { if ((e as Error)?.name !== "AbortError") toast.error("Couldn't create the PDF. Please try again."); }
    finally { setBusy(null); }
  };

  const download = () => withPdf("dl", (_b, doc) => { doc.save(fileName); toast.success("Report downloaded"); });
  const print = () => withPdf("print", (b) => {
    const url = URL.createObjectURL(b); const w = window.open(url);
    if (!w) { toast.error("Allow pop-ups to print, or download the PDF instead."); return; }
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  });
  const share = () => withPdf("share", async (b) => {
    const file = new File([b], fileName, { type: "application/pdf" });
    if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], title: "Sonder report" });
    else toast.info("Sharing isn't supported on this device. Download the PDF and attach it instead.");
  });

  return (
    <AppShell title="For Your Doctor" subtitle="Review a clinician-friendly summary, add notes, and export it as a PDF.">
      {!r && (
        <section className="card-surface mb-5 flex flex-col gap-3 p-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-muted-foreground">Complete a PHQ-9 screening to include your results in the report.</p>
          <Button asChild><Link to="/screening">Start screening <ArrowRight /></Link></Button>
        </section>
      )}
      <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
        <article className="card-surface space-y-6 p-6 sm:p-8" aria-label="Report preview">
          <header className="flex items-start justify-between border-b pb-4">
            <div><p className="eyebrow">Report preview</p><h2 className="mt-1 text-xl font-semibold">Patient-Reported Mental Health Summary</h2></div>
            <span className="text-sm text-muted-foreground">{new Date().toLocaleDateString()}</span>
          </header>

          <Section title="Summary">
            <Row k="Patient name" v={state.patientName || "Not provided"} />
            {r ? (<>
              <Row k="Assessment date" v={new Date(r.completedAt).toLocaleDateString(undefined, { dateStyle: "long" })} />
              <Row k="PHQ-9 total" v={`${r.score} / 27`} />
              <Row k="Severity" v={severityFor(r.score)} />
              <Row k="Screening outcome" v={isPositive(r.score) ? "Positive screen (≥ 10)" : "Negative screen (< 10)"} />
            </>) : <p className="text-sm text-muted-foreground">No screening completed.</p>}
          </Section>

          {r && (
            <Section title="PHQ-9 item responses (standardized questionnaire)">
              <ol className="divide-y text-sm">
                {PHQ9_ITEMS.map((q, i) => (
                  <li key={i} className={`flex justify-between gap-4 py-2 ${i === 8 && (r.answers[8] ?? 0) > 0 ? "font-medium text-destructive" : ""}`}>
                    <span>{i + 1}. {q}</span><span className="shrink-0 tabular-nums">{r.answers[i]} · {optionLabel(r.answers[i])}</span>
                  </li>
                ))}
              </ol>
            </Section>
          )}

          <Section title="Lifestyle context (self-reported)">
            {l.weekdaySleepHours == null && l.sedentaryHours == null && l.age == null ? <p className="text-sm text-muted-foreground">Not provided.</p> : (<>
              {l.weekdaySleepHours != null && <Row k="Weekday sleep" v={`${l.weekdaySleepHours} h`} />}
              {l.sedentaryHours != null && <Row k="Sedentary time" v={`${l.sedentaryHours} h/day`} />}
              {l.age != null && <Row k="Age" v={String(l.age)} />}
              {l.education != null && <Row k="Education" v={EDUCATION_LEVELS.find((e) => e.value === l.education)?.label ?? ""} />}
              {l.income != null && l.householdSize && <Row k="Income-to-poverty ratio" v={incomePovertyRatio(l.income, l.householdSize).toFixed(2)} />}
            </>)}
          </Section>

          <Section title="AI-assisted insights (exploratory, model-generated)">
            {state.aiInsight ? (<>
              <Row k="Model estimate" v={`${(state.aiInsight.probability * 100).toFixed(0)}% probability of elevated remaining-seven-item symptom burden`} />
              <Row k="Generated" v={new Date(state.aiInsight.computedAt).toLocaleDateString(undefined, { dateStyle: "long" })} />
              <p className="text-xs text-muted-foreground">Statistical estimate from a research model trained on NHANES population data — not a diagnosis. Distinct from the patient-reported symptoms above.</p>
            </>) : (
              <p className="text-sm text-muted-foreground">No machine-learning assessment was performed for this report.</p>
            )}
          </Section>

          <Section title="Patient notes">
            <Label htmlFor="notes" className="sr-only">Notes for your clinician</Label>
            <Textarea id="notes" rows={5} value={state.notes} onChange={(e) => update({ notes: e.target.value })}
              placeholder="Symptoms, questions, or concerns you'd like to discuss…" className="bg-card" />
          </Section>

          <p className="rounded-lg bg-secondary p-4 text-xs leading-relaxed">{DISCLAIMER}</p>
        </article>

        <aside className="space-y-4">
          <section className="card-surface space-y-3 p-5">
            <div>
              <Label htmlFor="pname">Name on report (optional)</Label>
              <Input id="pname" className="mt-1.5 bg-card" value={state.patientName} onChange={(e) => update({ patientName: e.target.value })} />
            </div>
            <Button className="h-11 w-full" onClick={download} disabled={!!busy}>{busy === "dl" ? <Loader2 className="animate-spin" /> : <Download />} Download PDF</Button>
            <Button variant="outline" className="h-11 w-full" onClick={print} disabled={!!busy}><Printer /> Print report</Button>
            <Button variant="outline" className="h-11 w-full" onClick={share} disabled={!!busy}><Share2 /> Share</Button>
          </section>
          <section className="card-surface p-5 text-sm">
            <h3 className="flex items-center gap-2 font-semibold"><Mail className="size-4 text-primary" aria-hidden /> Sending to your clinician</h3>
            <p className="mt-2 text-muted-foreground">Direct email isn't set up yet. Download the PDF, then attach it to an email or upload it to your clinic's secure patient portal. Reports are never posted to public links.</p>
          </section>
        </aside>
      </div>
    </AppShell>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <section><h3 className="mb-2 text-sm font-semibold text-primary">{title}</h3><div className="space-y-1">{children}</div></section>;
}
function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between gap-4 text-sm"><span className="text-muted-foreground">{k}</span><span className="text-right font-medium">{v}</span></div>;
}
