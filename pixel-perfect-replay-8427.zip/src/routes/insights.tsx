import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Bar, BarChart, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowRight, CheckCircle2, ChevronDown, Loader2, Plug, Sparkles, WifiOff } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useStore } from "@/lib/store";
import { toModelFeatures, countProvidedFeatures, FEATURE_META } from "@/lib/lifestyle";
import { PHQ9_ITEMS, isPositive, optionLabel, severityFor } from "@/lib/phq9";
import { checkModelStatus, predict, MODEL_CARD, type ModelStatus } from "@/services/modelApi";
import type { ModelResponse } from "@/lib/model.functions";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [
      { title: "AI Insights — Sonder" },
      { name: "description", content: "Explainable machine learning: explore factors associated with elevated depressive symptoms in NHANES data." },
      { property: "og:title", content: "AI Insights — Sonder" },
      { property: "og:description", content: "Explainable, research-based model insights with SHAP contributions." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Insights,
});

const STATUS: Record<ModelStatus, { label: string; icon: typeof Plug; tone: string }> = {
  checking: { label: "Checking connection…", icon: Loader2, tone: "bg-muted text-muted-foreground" },
  ready: { label: "Connected and ready", icon: CheckCircle2, tone: "bg-positive-soft text-positive" },
  processing: { label: "Processing analysis", icon: Loader2, tone: "bg-accent text-accent-foreground" },
  unavailable: { label: "Model temporarily unavailable", icon: WifiOff, tone: "bg-caution-soft text-caution" },
  not_configured: { label: "Model not configured", icon: Plug, tone: "bg-muted text-muted-foreground" },
};

function Insights() {
  const { state, update } = useStore();
  const features = toModelFeatures(state.lifestyle, state.latest?.answers);
  const provided = countProvidedFeatures(features);
  const [status, setStatus] = useState<ModelStatus>("checking");
  const [result, setResult] = useState<ModelResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => { checkModelStatus().then(setStatus); }, []);

  const run = useCallback(async () => {
    setStatus("processing"); setError(null);
    const r = await predict(features);
    if (r.ok) {
      setStatus("ready");
      setResult(r.data);
      update({
        aiInsight: {
          probability: r.data.probability,
          baseValue: r.data.base_value,
          target: r.data.target,
          contributions: r.data.contributions,
          computedAt: new Date().toISOString(),
        },
      });
    } else {
      setStatus(r.reason === "not_configured" ? "not_configured" : "unavailable");
      setError(r.message);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(features)]);

  useEffect(() => {
    if (status === "ready" && !result) run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const S = STATUS[status];
  const r = state.latest;

  return (
    <AppShell title="AI Insights" subtitle="An explainable model trained on NHANES population data explores patterns associated with elevated symptom burden. It does not diagnose depression.">
      <div className="space-y-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium ${S.tone}`} role="status">
            <S.icon className={`size-4 ${status === "checking" || status === "processing" ? "animate-spin" : ""}`} aria-hidden /> {S.label}
          </span>
          {error && <span className="text-sm text-muted-foreground">{error}</span>}
        </div>

        {/* 1. PHQ-9 results */}
        <section className="card-surface p-6 sm:p-8">
          <h2 className="text-lg font-semibold">Your PHQ-9 Results</h2>
          {r ? (
            <>
              <div className="mt-3 flex flex-wrap items-end gap-6">
                <div>
                  <p className="text-sm text-muted-foreground">Total score</p>
                  <p className="text-4xl font-semibold text-primary">{r.score}<span className="text-lg text-muted-foreground"> / 27</span></p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Severity</p>
                  <p className="text-2xl font-semibold">{severityFor(r.score)}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-sm font-medium ${isPositive(r.score) ? "bg-caution-soft text-caution" : "bg-positive-soft text-positive"}`}>
                  {isPositive(r.score) ? "Positive screen (≥ 10)" : "Negative screen (< 10)"}
                </span>
              </div>
              <ol className="mt-5 divide-y text-sm">
                {PHQ9_ITEMS.map((q, i) => (
                  <li key={i} className="flex justify-between gap-4 py-2">
                    <span className="text-muted-foreground">{i + 1}. {q}</span>
                    <span className="shrink-0 tabular-nums font-medium">{r.answers[i]} · {optionLabel(r.answers[i])}</span>
                  </li>
                ))}
              </ol>
            </>
          ) : (
            <div className="mt-3 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-muted-foreground">Complete the PHQ-9 questionnaire to see your score here. Items 1 and 2 also feed the model.</p>
              <Button asChild><Link to="/screening">Start screening <ArrowRight /></Link></Button>
            </div>
          )}
        </section>

        {/* 2. Model insights */}
        {!result && status !== "processing" && status !== "checking" && (
          <section className="card-surface p-6 sm:p-8">
            <Sparkles className="size-6 text-lavender" aria-hidden />
            <h2 className="mt-3 text-lg font-semibold">AI analysis is not currently available</h2>
            <p className="mt-1 text-muted-foreground">Your screening and educational tools are ready to use. No model results are shown — Sonder never substitutes simulated predictions.</p>
            {status === "unavailable" && <Button variant="outline" className="mt-4" onClick={run}>Try again</Button>}
          </section>
        )}

        {result && (
          <section className="card-surface p-6 sm:p-8">
            <p className="eyebrow">Exploratory model estimate</p>
            <div className="mt-3 flex flex-wrap items-end gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Estimated probability of elevated remaining-seven-item symptom burden</p>
                <p className="text-4xl font-semibold text-primary">{(result.probability * 100).toFixed(0)}%</p>
              </div>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              {result.target}. This is an exploratory statistical estimate based on {provided} of 25 inputs — it is not a diagnosis and does not use your full PHQ-9 score, history, or clinical context.
            </p>
          </section>
        )}

        {/* 3 + 4. Interactive SHAP chart with per-feature explanations */}
        {result && <ShapExplorer r={result} selected={selected} onSelect={setSelected} />}

        {provided < 25 && (
          <section className="card-surface flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="font-semibold">Improve your insights</h2>
              <p className="mt-1 text-sm text-muted-foreground">You've provided {provided} of 25 model inputs. Missing answers are estimated statistically — completing the lifestyle assessment makes insights more reliable.</p>
            </div>
            <Button asChild variant="outline"><Link to="/lifestyle">Complete lifestyle assessment <ArrowRight /></Link></Button>
          </section>
        )}

        {/* 5. Validation performance + transparency */}
        <ModelTransparency />
      </div>
    </AppShell>
  );
}

function ShapExplorer({ r, selected, onSelect }: { r: ModelResponse; selected: string | null; onSelect: (f: string | null) => void }) {
  const data = r.contributions.map((c) => ({
    ...c,
    label: FEATURE_META[c.feature]?.label ?? c.feature,
  }));
  const sel = data.find((d) => d.feature === selected) ?? null;

  return (
    <section className="card-surface p-6">
      <h2 className="text-lg font-semibold">What influenced this estimate?</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        SHAP values show how much each input moved the model's output from its baseline ({r.base_value.toFixed(2)}), on the log-odds scale.
        <span className="text-chart-5"> Positive</span> bars push the estimate higher; <span className="text-primary">negative</span> bars push it lower. Select a bar to learn more.
      </p>
      <div className="mt-4 h-[640px]" role="img" aria-label={data.map((d) => `${d.label}: ${d.shap_value > 0 ? "+" : ""}${d.shap_value.toFixed(3)}`).join("; ")}>
        <ResponsiveContainer>
          <BarChart data={data} layout="vertical" margin={{ left: 10, right: 20 }}>
            <XAxis type="number" tick={{ fontSize: 12 }} />
            <YAxis type="category" dataKey="label" width={200} tick={{ fontSize: 12 }} />
            <ReferenceLine x={0} stroke="var(--color-border)" />
            <Tooltip formatter={(v: number) => v.toFixed(3)} />
            <Bar dataKey="shap_value" radius={4} onClick={(d) => onSelect((d as unknown as { feature: string }).feature)} className="cursor-pointer">
              {data.map((d) => (
                <Cell key={d.feature}
                  fill={d.shap_value >= 0 ? "var(--color-chart-5)" : "var(--color-chart-1)"}
                  opacity={selected == null || selected === d.feature ? 1 : 0.35} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <ul className="sr-only">{data.map((d) => <li key={d.feature}>{d.label}, value {d.value ?? "not provided"}: {d.shap_value >= 0 ? "increases" : "decreases"} estimate by {Math.abs(d.shap_value).toFixed(3)}</li>)}</ul>

      {sel && (
        <div className="mt-4 rounded-xl bg-secondary p-5" role="region" aria-live="polite" aria-label={`Details for ${sel.label}`}>
          <div className="flex items-start justify-between gap-4">
            <h3 className="font-semibold">{sel.label}</h3>
            <Button variant="ghost" size="sm" onClick={() => onSelect(null)}>Close</Button>
          </div>
          <dl className="mt-3 grid gap-3 sm:grid-cols-3">
            <div className="rounded-lg bg-card p-3"><dt className="text-xs text-muted-foreground">Your input</dt><dd className="mt-1 font-medium">{sel.value ?? "Not provided (estimated)"}</dd></div>
            <div className="rounded-lg bg-card p-3"><dt className="text-xs text-muted-foreground">SHAP contribution</dt><dd className="mt-1 font-medium">{sel.shap_value >= 0 ? "+" : ""}{sel.shap_value.toFixed(3)} log-odds</dd></div>
            <div className="rounded-lg bg-card p-3"><dt className="text-xs text-muted-foreground">Direction</dt><dd className="mt-1 font-medium">{sel.shap_value >= 0 ? "Pushes the estimate higher" : "Pushes the estimate lower"}</dd></div>
          </dl>
          <p className="mt-3 text-sm text-muted-foreground">{FEATURE_META[sel.feature]?.explanation} This describes an association in population data — it does not mean this factor causes changes in symptoms.</p>
        </div>
      )}
    </section>
  );
}

function ModelTransparency() {
  const m = MODEL_CARD;
  return (
    <Collapsible className="card-surface">
      <CollapsibleTrigger className="group flex w-full items-center justify-between p-6 text-left font-semibold">
        How This AI Works <ChevronDown className="size-5 transition-transform group-data-[state=open]:rotate-180" aria-hidden />
      </CollapsibleTrigger>
      <CollapsibleContent className="space-y-4 px-6 pb-6 text-sm text-muted-foreground">
        <ul className="space-y-1.5">
          <li>• A CatBoost model developed using NHANES (National Health and Nutrition Examination Survey) population data.</li>
          <li>• It estimates whether the remaining seven PHQ-9 items (3–9) sum to at least 8 — a symptom-burden threshold, not a clinical diagnosis.</li>
          <li>• Performance is measured on held-out data the model never saw during training.</li>
          <li>• Predictions may be less reliable for groups underrepresented in NHANES.</li>
          <li>• Associations do not establish causation.</li>
          <li>• A healthcare professional should interpret findings alongside clinical information.</li>
        </ul>
        <dl className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <div className="rounded-lg bg-secondary p-3">
            <dt className="text-xs">Validation ROC-AUC</dt>
            <dd className="mt-1 font-medium text-foreground">{m.rocAuc != null ? `${(m.rocAuc * 100).toFixed(2)}%` : "Not yet reported"}</dd>
          </div>
          <div className="rounded-lg bg-secondary p-3">
            <dt className="text-xs">Model accuracy</dt>
            <dd className="mt-1 font-medium text-foreground">{m.accuracy != null ? `${(m.accuracy * 100).toFixed(2)}%` : "Not yet reported"}</dd>
          </div>
          <div className="rounded-lg bg-secondary p-3"><dt className="text-xs">Evaluation population</dt><dd className="mt-1 font-medium text-foreground">{m.evaluationPopulation ?? "Not yet reported"}</dd></div>
          <div className="rounded-lg bg-secondary p-3"><dt className="text-xs">Model</dt><dd className="mt-1 font-medium text-foreground">{m.version ?? "—"}</dd></div>
        </dl>
        <p>ROC-AUC measures how well the model distinguishes participants with elevated symptom burden from those without, across all possible thresholds. A value of 0.5 is no better than chance; 1.0 is perfect. It does not mean the model is right {(m.rocAuc ?? 0) * 100}% of the time.</p>
      </CollapsibleContent>
    </Collapsible>
  );
}
