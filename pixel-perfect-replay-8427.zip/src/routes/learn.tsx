import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Brain, CheckCircle2, HelpCircle, Moon, Users, ArrowRight } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { useStore } from "@/lib/store";
import { ACTIVITIES, type ActivityId } from "@/lib/activities";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "Learn — Sonder" },
      { name: "description", content: "Interactive, evidence-based activities about depression, the brain, sleep, and seeking support." },
      { property: "og:title", content: "Learn — Sonder" },
      { property: "og:description", content: "Interactive activities about depression, the brain, sleep, and support." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Learn,
});

const ICONS = { myth: HelpCircle, brain: Brain, sleep: Moon, support: Users };

function Learn() {
  const { state, update } = useStore();
  const [open, setOpen] = useState<ActivityId | null>(null);
  const complete = (id: ActivityId, score?: number, total?: number) =>
    update((s) => ({ learn: { ...s.learn, [id]: { completed: true, score, total } } }));
  const done = ACTIVITIES.filter((a) => state.learn[a.id]?.completed).length;
  const next = ACTIVITIES.find((a) => !state.learn[a.id]?.completed);

  if (open) {
    const a = ACTIVITIES.find((x) => x.id === open)!;
    const finish = (score?: number, total?: number) => complete(open, score, total);
    return (
      <AppShell title={a.title} subtitle={a.description}>
        <Button variant="ghost" className="mb-4 -ml-3" onClick={() => setOpen(null)}><ArrowLeft /> All activities</Button>
        <div className="max-w-3xl">
          {open === "myth" && <MythOrFact onDone={finish} />}
          {open === "brain" && <BrainModule onDone={finish} />}
          {open === "sleep" && <SleepModule onDone={finish} />}
          {open === "support" && <SupportScenarios onDone={finish} />}
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell title="Learn" subtitle="Short, evidence-based activities to understand depression and how support works.">
      <section className="card-surface mb-5 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
          <span className="font-medium">{done} of {ACTIVITIES.length} activities completed</span>
          {next && <span className="text-muted-foreground">Recommended next: <strong className="text-foreground">{next.title}</strong></span>}
        </div>
        <Progress value={(done / ACTIVITIES.length) * 100} className="mt-3 h-2" aria-label="Learning progress" />
      </section>
      <div className="grid gap-4 sm:grid-cols-2">
        {ACTIVITIES.map((a) => {
          const Icon = ICONS[a.id]; const p = state.learn[a.id];
          return (
            <button key={a.id} onClick={() => setOpen(a.id)} className="card-surface group flex flex-col p-6 text-left transition-shadow hover:shadow-lift">
              <div className="flex items-start justify-between">
                <div className="grid size-11 place-items-center rounded-xl bg-secondary text-primary"><Icon aria-hidden /></div>
                {p?.completed && <span className="flex items-center gap-1 text-xs font-medium text-positive"><CheckCircle2 className="size-4" aria-hidden /> Completed{p.total ? ` · ${p.score}/${p.total}` : ""}</span>}
              </div>
              <h2 className="mt-4 font-semibold">{a.title}</h2>
              <p className="mt-1 flex-1 text-sm text-muted-foreground">{a.description}</p>
              <span className="mt-4 flex items-center gap-1 text-sm font-medium text-primary">{a.minutes} min · {p?.completed ? "Review" : "Start"} <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" /></span>
            </button>
          );
        })}
      </div>
    </AppShell>
  );
}

type Done = { onDone: (score?: number, total?: number) => void };

const MYTHS = [
  { s: "Depression is simply a lack of motivation.", fact: false, e: "Depression is a health condition involving mood, thinking, sleep, energy, and body changes. Low motivation can be a symptom — not the cause or a character flaw." },
  { s: "Depression can affect sleep and concentration.", fact: true, e: "Sleep changes and difficulty concentrating are common symptoms, and both appear among the nine PHQ-9 items." },
  { s: "Seeking professional support can be an important part of recovery.", fact: true, e: "Psychotherapy, medication, or a combination are effective for many people. A professional can help find what fits." },
  { s: "Everyone experiences depression in exactly the same way.", fact: false, e: "Symptoms vary widely. Some people feel sad; others mostly feel numb, irritable, exhausted, or notice physical symptoms." },
  { s: "Depression is caused by a single chemical imbalance.", fact: false, e: "Current research points to many interacting factors — genetics, brain circuits, stress, life events, health, and social context." },
  { s: "Talking about suicide makes someone more likely to act on it.", fact: false, e: "Asking directly and caringly does not increase risk, and can help someone feel heard and connect with support." },
];

function MythOrFact({ onDone }: Done) {
  const [i, setI] = useState(0); const [ans, setAns] = useState<boolean | null>(null); const [score, setScore] = useState(0); const [end, setEnd] = useState(false);
  if (end) return (
    <section className="card-surface p-8 text-center">
      <CheckCircle2 className="mx-auto size-10 text-positive" aria-hidden />
      <h2 className="mt-3 text-xl font-semibold">Nice work — you reviewed all {MYTHS.length} statements</h2>
      <p className="mt-1 text-muted-foreground">You answered {score} of {MYTHS.length} in line with current evidence.</p>
      <Button className="mt-5" onClick={() => { setI(0); setAns(null); setScore(0); setEnd(false); }}>Try again</Button>
    </section>
  );
  const m = MYTHS[i]!;
  const pick = (v: boolean) => { if (ans !== null) return; setAns(v); if (v === m.fact) setScore(score + 1); };
  return (
    <section className="card-surface p-6 sm:p-8">
      <Progress value={(i / MYTHS.length) * 100} className="h-1.5" aria-label={`Statement ${i + 1} of ${MYTHS.length}`} />
      <p className="eyebrow mt-5">Statement {i + 1} of {MYTHS.length}</p>
      <h2 className="mt-2 text-xl font-semibold">“{m.s}”</h2>
      <div className="mt-5 grid grid-cols-2 gap-3">
        {[false, true].map((v) => (
          <Button key={String(v)} variant={ans === v ? "default" : "outline"} size="lg" className="h-12" onClick={() => pick(v)} disabled={ans !== null && ans !== v}>{v ? "Fact" : "Myth"}</Button>
        ))}
      </div>
      {ans !== null && (
        <div className="mt-5 rounded-xl bg-secondary p-4 fade-up" role="status">
          <p className="font-semibold">{ans === m.fact ? "That's right." : "Not quite."} This is a {m.fact ? "fact" : "myth"}.</p>
          <p className="mt-1 text-sm">{m.e}</p>
          <Button className="mt-4" onClick={() => { if (i === MYTHS.length - 1) { setEnd(true); onDone(score, MYTHS.length); } else { setI(i + 1); setAns(null); } }}>
            {i === MYTHS.length - 1 ? "See summary" : "Next statement"}
          </Button>
        </div>
      )}
    </section>
  );
}

const REGIONS = {
  pfc: { name: "Prefrontal cortex", body: "Supports planning, decision-making, and regulating emotions. In depression, research finds changes in how this area communicates with emotional centers, which may make it harder to shift out of negative thoughts." },
  amygdala: { name: "Amygdala", body: "Helps detect threats and assign emotional importance. Studies often observe heightened amygdala responses to negative information during depression." },
  hippocampus: { name: "Hippocampus", body: "Involved in memory and context. It is sensitive to long-term stress hormones, and some studies find reduced hippocampal volume in recurrent depression." },
  signaling: { name: "Neural signaling", body: "Neurons communicate using chemicals like serotonin, dopamine, norepinephrine, and glutamate. Depression is not simply 'low serotonin' — it involves networks, signaling, and adaptability (neuroplasticity)." },
  hpa: { name: "Stress response (HPA axis)", body: "The hypothalamus, pituitary, and adrenal glands coordinate cortisol release under stress. Prolonged stress can disrupt this system, which is linked with mood, sleep, and energy changes." },
} as const;
type RegionKey = keyof typeof REGIONS;

function BrainModule({ onDone }: Done) {
  const [sel, setSel] = useState<RegionKey>("pfc"); const [seen, setSeen] = useState<Set<RegionKey>>(new Set(["pfc"]));
  const choose = (k: RegionKey) => { setSel(k); const n = new Set(seen); n.add(k); setSeen(n); if (n.size === 5) onDone(); };
  const spot = (k: RegionKey, cx: number, cy: number, r: number) => (
    <g role="button" tabIndex={0} aria-label={REGIONS[k].name} onClick={() => choose(k)} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && choose(k)} className="cursor-pointer focus:outline-none">
      <circle cx={cx} cy={cy} r={r} className={`transition-colors ${sel === k ? "fill-primary" : "fill-lavender/50 hover:fill-lavender"}`} />
      <circle cx={cx} cy={cy} r={r + 6} className={`fill-none ${sel === k ? "stroke-primary" : "stroke-transparent"}`} strokeWidth="2" strokeDasharray="4 4" />
    </g>
  );
  return (
    <section className="card-surface grid gap-6 p-6 md:grid-cols-2">
      <svg viewBox="0 0 300 240" className="w-full" aria-label="Brain diagram — select a region">
        <path d="M60 140c-30-10-35-70 5-90 15-35 75-45 105-25 35-15 85 0 95 40 30 20 20 75-15 80-5 25-40 35-60 20-25 15-60 10-70-10-30 5-55-0-60-15z" className="fill-secondary stroke-border" strokeWidth="2" />
        <path d="M150 175c5 20 0 35-10 50" className="stroke-border" strokeWidth="10" fill="none" strokeLinecap="round" />
        {spot("pfc", 85, 85, 16)}
        {spot("amygdala", 150, 140, 11)}
        {spot("hippocampus", 185, 135, 12)}
        {spot("signaling", 210, 75, 13)}
        {spot("hpa", 140, 175, 10)}
      </svg>
      <div>
        <div className="flex flex-wrap gap-1.5">
          {(Object.keys(REGIONS) as RegionKey[]).map((k) => (
            <button key={k} onClick={() => choose(k)} className={`rounded-full px-3 py-1 text-xs font-medium ${sel === k ? "bg-primary text-primary-foreground" : seen.has(k) ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}>{REGIONS[k].name}</button>
          ))}
        </div>
        <h2 className="mt-5 text-xl font-semibold">{REGIONS[sel].name}</h2>
        <p className="mt-2 leading-relaxed text-muted-foreground">{REGIONS[sel].body}</p>
        <p className="mt-5 text-sm">{seen.size} of 5 explored{seen.size === 5 && " — activity complete"}</p>
      </div>
    </section>
  );
}

function sleepNote(h: number) {
  if (h < 6) return { t: "Short sleep", b: "In population studies, regularly sleeping under 6 hours is associated with higher rates of depressive symptoms. The relationship goes both ways: depression can disrupt sleep, and poor sleep can worsen mood." };
  if (h <= 9) return { t: "Typical recommended range", b: "Most adults are advised to get 7–9 hours. Even within this range, consistency, timing, and sleep quality also matter for mood." };
  return { t: "Long sleep", b: "Regularly sleeping much longer than 9 hours is also associated with depressive symptoms in research. Sleeping too much is itself a PHQ-9 symptom and can reflect low energy or other health issues." };
}

function SleepModule({ onDone }: Done) {
  const [h, setH] = useState(7); const [tries, setTries] = useState(new Set<string>());
  const n = sleepNote(h);
  const move = (v: number) => { setH(v); const s = new Set(tries); s.add(sleepNote(v).t); setTries(s); if (s.size === 3) onDone(); };
  return (
    <section className="card-surface p-6 sm:p-8">
      <p className="text-sm text-muted-foreground">Move the slider to explore sleep-duration scenarios. This is general education about population-level associations — not a personal prediction.</p>
      <div className="mt-6 flex items-end justify-between"><span className="text-sm font-medium">Hours of sleep per night</span><span className="text-3xl font-semibold text-primary">{h} h</span></div>
      <Slider className="mt-3" aria-label="Hours of sleep" min={3} max={12} step={0.5} value={[h]} onValueChange={([v]) => move(v ?? h)} />
      <div className="mt-6 rounded-xl bg-secondary p-5 fade-up" key={n.t}>
        <h2 className="font-semibold">{n.t}</h2><p className="mt-1 text-sm leading-relaxed">{n.b}</p>
      </div>
      <p className="mt-4 text-xs text-muted-foreground">No specific number of hours will cure depression. If sleep is a struggle, it's worth raising with a clinician — treatments like CBT for insomnia can help. Explored {tries.size} of 3 scenarios.</p>
    </section>
  );
}

const SCENARIOS = [
  { q: "For three weeks, Maya has felt low most days and no longer enjoys painting, which she used to love.", opts: [
    { a: "Wait it out — everyone has bad weeks.", k: "self", f: "Bad days are normal, but low mood and loss of interest lasting two weeks or more are worth talking with a professional about." },
    { a: "Book an appointment with a doctor or therapist.", k: "pro", f: "A good step. Persistent low mood plus loss of interest are core depression symptoms, and a professional can evaluate them." },
  ]},
  { q: "Jordan has trouble concentrating at work and is sleeping poorly during a stressful month, but mood is otherwise okay.", opts: [
    { a: "Try sleep routines, breaks, and talking with friends — and check in with a doctor if it continues.", k: "self", f: "Reasonable. Self-care can help with short-term stress; if problems persist or worsen, professional support is a good next step." },
    { a: "Ignore it completely.", k: "none", f: "It's better to notice and respond. Small steps now, and checking in later if it continues, are healthier than ignoring it." },
  ]},
  { q: "A friend texts that they feel like a burden and that everyone would be better off without them.", opts: [
    { a: "Ask directly if they're thinking about suicide, stay with them, and help them contact 988.", k: "urgent", f: "This is the right response. These words can signal suicidal thoughts. Asking directly is safe; connect them with 988 or 911 if in immediate danger." },
    { a: "Change the subject to cheer them up.", k: "none", f: "Their message may signal a safety concern. Take it seriously: ask directly, listen, and help them reach 988 or emergency services." },
  ]},
  { q: "Sam wonders whether symptoms are 'bad enough' to see a therapist.", opts: [
    { a: "Only see a therapist if things become unbearable.", k: "none", f: "You don't need to be in crisis to deserve support. Therapy can help at any level of difficulty." },
    { a: "Reach out now — therapists can help at any stage.", k: "pro", f: "Exactly. Early support is often easier and more effective. A PHQ-9 report can help start that conversation." },
  ]},
];
const KIND = { self: "Self-care", pro: "Professional support", urgent: "Urgent safety", none: "Reconsider" } as const;

function SupportScenarios({ onDone }: Done) {
  const [i, setI] = useState(0); const [pick, setPick] = useState<number | null>(null);
  const s = SCENARIOS[i]!;
  return (
    <section className="card-surface p-6 sm:p-8">
      <p className="eyebrow">Scenario {i + 1} of {SCENARIOS.length} · fictional</p>
      <h2 className="mt-2 text-lg font-semibold leading-snug">{s.q}</h2>
      <p className="mt-1 text-sm text-muted-foreground">What would you suggest?</p>
      <div className="mt-4 grid gap-2.5">
        {s.opts.map((o, j) => (
          <button key={j} onClick={() => setPick(j)} disabled={pick !== null}
            className={`rounded-xl border p-4 text-left text-sm font-medium transition-colors ${pick === j ? "border-primary bg-accent" : "bg-card hover:bg-secondary"} disabled:cursor-default`}>{o.a}</button>
        ))}
      </div>
      {pick !== null && (
        <div className={`mt-5 rounded-xl p-4 fade-up ${s.opts[pick]!.k === "urgent" ? "bg-destructive-soft" : s.opts[pick]!.k === "none" ? "bg-caution-soft" : "bg-positive-soft"}`} role="status">
          <p className="eyebrow">{KIND[s.opts[pick]!.k as keyof typeof KIND]}</p>
          <p className="mt-1 text-sm">{s.opts[pick]!.f}</p>
          <Button className="mt-4" onClick={() => { if (i === SCENARIOS.length - 1) { onDone(); setI(0); } else setI(i + 1); setPick(null); }}>
            {i === SCENARIOS.length - 1 ? "Finish" : "Next scenario"}
          </Button>
        </div>
      )}
    </section>
  );
}
