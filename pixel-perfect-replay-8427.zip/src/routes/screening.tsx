import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ArrowRight, Check, Info, RotateCcw } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CrisisResources } from "@/components/CrisisResources";
import { ScreeningResultCard } from "@/components/ScreeningResultCard";
import { useStore } from "@/lib/store";
import { PHQ9_ITEMS, PHQ9_OPTIONS, PHQ9_STEM, needsSafetySupport, scorePhq9 } from "@/lib/phq9";

export const Route = createFileRoute("/screening")({
  head: () => ({
    meta: [
      { title: "PHQ-9 Screening — Sonder" },
      { name: "description", content: "Complete the standardized nine-question PHQ-9 depression screening questionnaire." },
      { property: "og:title", content: "PHQ-9 Screening — Sonder" },
      { property: "og:description", content: "A standardized nine-question screening for depressive symptoms." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Screening,
});

function Screening() {
  const { state, update } = useStore();
  const [view, setView] = useState<"intro" | "questions" | "results">(state.draftAnswers.some((a) => a !== null) ? "questions" : "intro");
  const answers = state.draftAnswers;
  const idx = state.draftIndex;
  const answered = answers.filter((a) => a !== null).length;
  const showSafety = needsSafetySupport(answers);

  const choose = (v: number) => {
    const next = [...answers]; next[idx] = v;
    update({ draftAnswers: next, draftIndex: idx < 8 && v !== null ? Math.min(8, idx + 1) : idx });
  };

  const submit = () => {
    const score = scorePhq9(answers);
    const result = { answers: answers as number[], score, completedAt: new Date().toISOString() };
    update((s) => ({ latest: result, history: [result, ...s.history].slice(0, 20), draftAnswers: Array(9).fill(null), draftIndex: 0 }));
    setView("results");
    window.scrollTo({ top: 0 });
  };

  if (view === "results" && state.latest) {
    return (
      <AppShell title="Your screening results" subtitle="Here's a summary of your responses from the last two weeks.">
        <div className="space-y-5">
          {needsSafetySupport(state.latest.answers) && <CrisisResources />}
          <ScreeningResultCard result={state.latest} />
          <section className="card-surface p-6">
            <h2 className="font-semibold">Suggested next steps</h2>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li>• Share these results with a doctor, therapist, or counselor — they can provide a full evaluation.</li>
              <li>• Add lifestyle information to explore research-based patterns (optional).</li>
              <li>• Learn more about depression through short interactive activities.</li>
            </ul>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button asChild><Link to="/lifestyle">Continue to lifestyle assessment <ArrowRight /></Link></Button>
              <Button asChild variant="outline"><Link to="/doctor">Prepare a doctor report</Link></Button>
              <Button asChild variant="ghost"><Link to="/overview">Go to Overview</Link></Button>
            </div>
          </section>
        </div>
      </AppShell>
    );
  }

  if (view === "intro") {
    return (
      <AppShell title="PHQ-9 Screening" subtitle="A standardized, nine-question questionnaire widely used in primary care.">
        <section className="card-surface max-w-2xl p-6 sm:p-8">
          <p className="text-lg font-medium">“{PHQ9_STEM}”</p>
          <div className="mt-5 flex gap-3 rounded-xl bg-secondary p-4 text-sm">
            <Info className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
            <p>The PHQ-9 is a screening questionnaire, not a diagnostic examination. Only a licensed professional can diagnose depression. Answer honestly — there are no right or wrong answers.</p>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">9 questions · about 3 minutes · answers stay on this device</p>
          <div className="mt-6 flex flex-wrap gap-2">
            <Button size="lg" className="h-12" onClick={() => setView("questions")}>Begin <ArrowRight /></Button>
            {state.latest && <Button size="lg" variant="outline" className="h-12" onClick={() => setView("results")}>View last results</Button>}
          </div>
        </section>
      </AppShell>
    );
  }

  return (
    <AppShell title="PHQ-9 Screening" subtitle={PHQ9_STEM}>
      <div className="max-w-2xl space-y-5">
        <div>
          <div className="mb-2 flex justify-between text-sm">
            <span className="font-medium">Question {idx + 1} of 9</span>
            <span className="text-muted-foreground">{answered} answered</span>
          </div>
          <Progress value={(answered / 9) * 100} className="h-2" aria-label={`${answered} of 9 answered`} />
        </div>

        <section key={idx} className="card-surface p-6 sm:p-8 fade-up" aria-labelledby="q">
          <h2 id="q" className="text-xl font-semibold leading-snug sm:text-2xl">{PHQ9_ITEMS[idx]}</h2>
          <div role="radiogroup" aria-labelledby="q" className="mt-6 grid gap-2.5">
            {PHQ9_OPTIONS.map((o) => {
              const sel = answers[idx] === o.value;
              return (
                <button
                  key={o.value}
                  role="radio"
                  aria-checked={sel}
                  onClick={() => choose(o.value)}
                  className={`flex min-h-14 items-center justify-between rounded-xl border px-4 text-left font-medium transition-colors ${sel ? "border-primary bg-accent text-accent-foreground" : "bg-card hover:bg-secondary"}`}
                >
                  <span>{o.label}</span>
                  <span className={`grid size-6 place-items-center rounded-full border ${sel ? "border-primary bg-primary text-primary-foreground" : ""}`}>
                    {sel && <Check className="size-3.5" aria-hidden />}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {showSafety && <CrisisResources />}

        <div className="flex flex-wrap items-center justify-between gap-2">
          <Button variant="ghost" disabled={idx === 0} onClick={() => update({ draftIndex: idx - 1 })}><ArrowLeft /> Previous</Button>
          <div className="flex gap-2">
            {idx < 8 ? (
              <Button variant="outline" onClick={() => update({ draftIndex: idx + 1 })}>Next <ArrowRight /></Button>
            ) : (
              <Button onClick={submit} disabled={answered < 9}>See my results</Button>
            )}
          </div>
        </div>
        {idx === 8 && answered < 9 && (
          <p className="text-sm text-caution" role="status">
            Please answer all questions before submitting. Unanswered: {answers.map((a, i) => (a === null ? i + 1 : null)).filter(Boolean).join(", ")}
          </p>
        )}
        <div className="flex flex-wrap gap-1.5" aria-label="Jump to question">
          {answers.map((a, i) => (
            <button key={i} onClick={() => update({ draftIndex: i })} aria-label={`Question ${i + 1}${a !== null ? ", answered" : ""}`}
              className={`size-9 rounded-lg text-sm font-medium ${i === idx ? "ring-2 ring-ring" : ""} ${a !== null ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
              {i + 1}
            </button>
          ))}
          {answered > 0 && (
            <button onClick={() => update({ draftAnswers: Array(9).fill(null), draftIndex: 0 })} className="ml-auto flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
              <RotateCcw className="size-3.5" aria-hidden /> Start over
            </button>
          )}
        </div>
      </div>
    </AppShell>
  );
}
