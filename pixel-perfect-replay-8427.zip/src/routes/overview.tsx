import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BedDouble, Armchair, User, Sparkles, Stethoscope, GraduationCap, ClipboardList } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { ScreeningResultCard } from "@/components/ScreeningResultCard";
import { CrisisResources } from "@/components/CrisisResources";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useStore } from "@/lib/store";
import { needsSafetySupport } from "@/lib/phq9";
import { EDUCATION_LEVELS } from "@/lib/lifestyle";
import { checkModelStatus, type ModelStatus } from "@/services/modelApi";
import { ACTIVITIES } from "@/lib/activities";

export const Route = createFileRoute("/overview")({
  head: () => ({
    meta: [
      { title: "Overview — Sonder" },
      { name: "description", content: "Your mental health overview: screening summary, lifestyle snapshot, and next steps." },
      { property: "og:title", content: "Overview — Sonder" },
      { property: "og:description", content: "Your screening summary, lifestyle snapshot, and next steps." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Overview,
});

function Overview() {
  const { state } = useStore();
  const { latest, lifestyle, learn } = state;
  const [model, setModel] = useState<ModelStatus>("checking");
  useEffect(() => { checkModelStatus().then(setModel); }, []);
  const done = ACTIVITIES.filter((a) => learn[a.id]?.completed).length;

  return (
    <AppShell title="Your Mental Health Overview" subtitle="Understand your current symptoms, explore meaningful patterns, and take informed next steps.">
      <div className="space-y-5">
        {latest && needsSafetySupport(latest.answers) && <CrisisResources compact />}

        {latest ? (
          <ScreeningResultCard result={latest} />
        ) : (
          <section className="card-surface flex flex-col items-start gap-4 p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8">
            <div className="flex items-start gap-4">
              <div className="grid size-12 shrink-0 place-items-center rounded-xl bg-secondary text-primary"><ClipboardList aria-hidden /></div>
              <div>
                <h2 className="text-xl font-semibold">No screening yet</h2>
                <p className="mt-1 text-muted-foreground">The PHQ-9 takes about 3 minutes. Your results will appear here.</p>
              </div>
            </div>
            <Button asChild size="lg" className="h-12"><Link to="/screening">Start Your Screening <ArrowRight /></Link></Button>
          </section>
        )}

        <section aria-labelledby="ls">
          <div className="mb-3 flex items-center justify-between">
            <h2 id="ls" className="font-semibold">Lifestyle snapshot</h2>
            <Link to="/lifestyle" className="text-sm font-medium text-primary hover:underline">Update</Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Snapshot icon={BedDouble} label="Weekday sleep" value={lifestyle.weekdaySleepHours != null ? `${lifestyle.weekdaySleepHours} h` : null} />
            <Snapshot icon={Armchair} label="Daily sedentary time" value={lifestyle.sedentaryHours != null ? `${lifestyle.sedentaryHours} h` : null} />
            <Snapshot icon={User} label="Profile" value={lifestyle.age != null ? `Age ${lifestyle.age}${lifestyle.education ? " · " + EDUCATION_LEVELS.find((e) => e.value === lifestyle.education)?.label : ""}` : null} />
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-2">
          <section className="card-surface flex flex-col p-6">
            <div className="grid size-10 place-items-center rounded-lg bg-lavender-soft text-lavender"><Sparkles className="size-5" aria-hidden /></div>
            <h2 className="mt-4 text-lg font-semibold">What Factors Might Be Associated With Your Symptoms?</h2>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {model === "ready"
                ? "Sonder's research-based model is connected. Explore which lifestyle factors the model associates with elevated symptoms in NHANES participants."
                : model === "checking"
                  ? "Checking AI availability…"
                  : "AI analysis is not currently available. Your screening and educational tools are ready to use."}
            </p>
            <Button asChild variant="outline" className="mt-5 self-start"><Link to="/insights">Explore AI Insights <ArrowRight /></Link></Button>
          </section>

          <section className="card-surface flex flex-col bg-primary p-6 text-primary-foreground">
            <Stethoscope className="size-6" aria-hidden />
            <h2 className="mt-4 text-lg font-semibold">Your Care, Your Clinician</h2>
            <p className="mt-2 flex-1 text-sm text-primary-foreground/85">Your screening results can help start a conversation with a licensed healthcare professional.</p>
            <Button asChild variant="secondary" className="mt-5 self-start"><Link to="/doctor">Prepare a Doctor Report <ArrowRight /></Link></Button>
          </section>
        </div>

        <section className="card-surface p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <GraduationCap className="size-5 text-primary" aria-hidden />
              <h2 className="font-semibold">Learning activities</h2>
            </div>
            <span className="text-sm text-muted-foreground">{done} of {ACTIVITIES.length} completed</span>
          </div>
          <Progress value={(done / ACTIVITIES.length) * 100} className="mt-3 h-2" aria-label="Learning progress" />
          <ul className="mt-4 grid gap-2 sm:grid-cols-2">
            {ACTIVITIES.map((a) => (
              <li key={a.id} className="flex items-center justify-between rounded-lg bg-secondary px-3 py-2.5 text-sm">
                <span>{a.title}</span>
                <span className={learn[a.id]?.completed ? "text-positive font-medium" : "text-muted-foreground"}>{learn[a.id]?.completed ? "Completed" : "Not started"}</span>
              </li>
            ))}
          </ul>
          <Button asChild variant="outline" className="mt-5"><Link to="/learn">Explore Learning Activities <ArrowRight /></Link></Button>
        </section>
      </div>
    </AppShell>
  );
}

function Snapshot({ icon: Icon, label, value }: { icon: typeof User; label: string; value: string | null }) {
  return (
    <Link to={value ? "/insights" : "/lifestyle"} className="card-surface block p-4 transition-shadow hover:shadow-lift">
      <div className="flex items-center gap-2 text-muted-foreground"><Icon className="size-4" aria-hidden /><span className="text-xs font-medium">{label}</span></div>
      <p className="mt-2 text-lg font-semibold">{value ?? <span className="text-sm font-normal text-muted-foreground">Not provided — add</span>}</p>
    </Link>
  );
}
