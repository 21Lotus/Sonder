// Model-agnostic client. All requests go through a server-side proxy so the
// model endpoint and any credentials never reach the browser.
import { getModelStatus, runPrediction, type ModelResult } from "@/lib/model.functions";
import type { ModelFeatures } from "@/lib/lifestyle";

export type ModelStatus = "checking" | "ready" | "processing" | "unavailable" | "not_configured";

export const MODEL_ENABLED = import.meta.env["VITE_MODEL_API_ENABLED"] !== "false";

export async function checkModelStatus(): Promise<ModelStatus> {
  if (!MODEL_ENABLED) return "not_configured";
  try {
    return (await getModelStatus()).status;
  } catch {
    return "unavailable";
  }
}

export async function predict(features: ModelFeatures): Promise<ModelResult> {
  if (!MODEL_ENABLED) return { ok: false, reason: "not_configured", message: "The AI model is not configured." };
  try {
    return await runPrediction({ data: features });
  } catch {
    return { ok: false, reason: "unavailable", message: "The model service could not be reached." };
  }
}

// Evaluation metrics reported for the trained model artifact.
export const MODEL_CARD = {
  rocAuc: 0.9162 as number | null,
  accuracy: 0.9333 as number | null,
  evaluationPopulation: "Held-out NHANES participants" as string | null,
  version: "symptom-informed-catboost" as string | null,
};
