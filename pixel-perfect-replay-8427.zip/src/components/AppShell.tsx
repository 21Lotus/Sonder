import { Link, useNavigate } from "@tanstack/react-router";
import { LayoutDashboard, ClipboardList, Sparkles, GraduationCap, Stethoscope, Settings, LifeBuoy } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { useStore } from "@/lib/store";
import { Logo } from "./Logo";

const NAV = [
  { to: "/overview", label: "Overview", icon: LayoutDashboard },
  { to: "/screening", label: "Screening", icon: ClipboardList },
  { to: "/insights", label: "AI Insights", icon: Sparkles },
  { to: "/learn", label: "Learn", icon: GraduationCap },
  { to: "/doctor", label: "For Your Doctor", short: "Doctor", icon: Stethoscope },
] as const;

export function AppShell({ children, title, subtitle, requireOnboarding = true }: {
  children: ReactNode; title: string; subtitle?: string; requireOnboarding?: boolean;
}) {
  const { state, hydrated } = useStore();
  const navigate = useNavigate();
  useEffect(() => {
    if (requireOnboarding && hydrated && !state.onboarded) navigate({ to: "/" });
  }, [hydrated, state.onboarded, requireOnboarding, navigate]);

  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r bg-sidebar px-4 py-6 lg:flex">
        <Link to="/overview" className="px-2"><Logo /></Link>
        <nav aria-label="Primary" className="mt-8 flex flex-1 flex-col gap-1">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
              activeProps={{ className: "bg-sidebar-accent !text-sidebar-accent-foreground" }}
            >
              <n.icon className="size-[18px]" aria-hidden /> {n.label}
            </Link>
          ))}
          <div className="my-3 border-t" />
          <Link
            to="/settings"
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
            activeProps={{ className: "bg-sidebar-accent !text-sidebar-accent-foreground" }}
          >
            <Settings className="size-[18px]" aria-hidden /> Settings
          </Link>
        </nav>
        <a href="tel:988" className="rounded-xl bg-secondary p-3 text-xs leading-relaxed text-secondary-foreground">
          <span className="flex items-center gap-2 font-semibold"><LifeBuoy className="size-4 text-primary" aria-hidden /> Need help now?</span>
          Call or text <strong>988</strong> — Suicide &amp; Crisis Lifeline, 24/7.
        </a>
      </aside>

      <header className="sticky top-0 z-20 flex items-center justify-between border-b bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
        <Link to="/overview"><Logo /></Link>
        <div className="flex items-center gap-1">
          <a href="tel:988" className="rounded-full px-3 py-1.5 text-xs font-semibold text-primary hover:bg-secondary">Crisis: 988</a>
          <Link to="/settings" aria-label="Settings & profile" className="grid size-10 place-items-center rounded-full hover:bg-secondary">
            <Settings className="size-5" aria-hidden />
          </Link>
        </div>
      </header>

      <main className="pb-28 lg:pb-12 lg:pl-64">
        <div className="mx-auto max-w-5xl px-4 pt-6 sm:px-6 lg:px-10 lg:pt-10">
          <div className="mb-6 fade-up lg:mb-8">
            <h1 className="text-2xl font-semibold sm:text-3xl">{title}</h1>
            {subtitle && <p className="mt-1.5 max-w-2xl text-muted-foreground">{subtitle}</p>}
          </div>
          {children}
        </div>
      </main>

      <nav aria-label="Primary" className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        {NAV.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            className="flex min-h-16 flex-col items-center justify-center gap-1 text-[11px] font-medium text-muted-foreground"
            activeProps={{ className: "!text-primary" }}
          >
            <n.icon className="size-5" aria-hidden />
            {"short" in n ? n.short : n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
