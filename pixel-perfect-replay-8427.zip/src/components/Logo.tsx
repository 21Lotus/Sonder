export function Logo() {
  return (
    <span className="flex items-center gap-2">
      <svg viewBox="0 0 32 32" className="size-8" aria-hidden>
        <rect width="32" height="32" rx="9" className="fill-primary" />
        <path d="M8 20c2.5-6 5-6 8 0s5.5 6 8 0" className="stroke-primary-foreground" strokeWidth="2.4" fill="none" strokeLinecap="round" />
        <circle cx="16" cy="11" r="2.4" className="fill-lavender" />
      </svg>
      <span className="text-lg font-semibold tracking-tight">Sonder</span>
    </span>
  );
}
