import { CheckCircle2, AlertCircle } from "lucide-react";
import { interpretation, isPositive, severityFor, POSITIVE_THRESHOLD } from "@/lib/phq9";
import type { ScreeningResult } from "@/lib/store";

const BANDS = [
  { max: 4, label: "Minimal" }, { max: 9, label: "Mild" }, { max: 14, label: "Moderate" },
  { max: 19, label: "Mod. severe" }, { max: 27, label: "Severe" },
];

export function ScreeningResultCard({ result }: { result: ScreeningResult }) {
  const pos = isPositive(result.score);
  const sev = severityFor(result.score);
  return (
    <section className="card-surface overflow-hidden" aria-labelledby="result-title">
      <div className="grid gap-6 p-6 sm:p-8 md:grid-cols-[auto_1fr] md:items-center">
        <div className="flex items-end gap-1">
          <span className="text-6xl font-semibold leading-none text-primary">{result.score}</span>
          <span className="pb-1 text-lg text-muted-foreground">/ 27</span>
        </div>
        <div>
          <p className="eyebrow">PHQ-9 · {new Date(result.completedAt).toLocaleDateString(undefined, { dateStyle: "long" })}</p>
          <h2 id="result-title" className="mt-1 text-2xl font-semibold">{sev} symptoms</h2>
          <p className={`mt-2 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-medium ${pos ? "bg-caution-soft text-caution" : "bg-positive-soft text-positive"}`}>
            {pos ? <AlertCircle className="size-4" aria-hidden /> : <CheckCircle2 className="size-4" aria-hidden />}
            {pos ? "Positive screening result" : "Negative screening result"} (threshold ≥ {POSITIVE_THRESHOLD})
          </p>
        </div>
      </div>
      <div className="px-6 sm:px-8">
        <div className="flex gap-1" role="img" aria-label={`Score ${result.score} falls in the ${sev} range`}>
          {BANDS.map((b, i) => {
            const active = sev.startsWith(b.label.replace("Mod.", "Moderately").split(" ")[0] ?? "") && result.score <= b.max && (i === 0 || result.score > BANDS[i - 1]!.max);
            return (
              <div key={b.label} className="flex-1">
                <div className={`h-2 rounded-full ${active ? "bg-primary" : "bg-muted"}`} />
                <p className={`mt-1.5 text-[11px] ${active ? "font-semibold text-foreground" : "text-muted-foreground"}`}>{b.label}</p>
              </div>
            );
          })}
        </div>
      </div>
      <p className="border-t bg-secondary/50 px-6 py-4 text-sm leading-relaxed sm:px-8 mt-5">
        {interpretation(result.score)} <span className="text-muted-foreground">The PHQ-9 is a screening tool, not a diagnosis.</span>
      </p>
    </section>
  );
}
