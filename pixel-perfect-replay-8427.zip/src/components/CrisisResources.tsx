import { Phone, MessageSquare, Siren, HeartHandshake } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CrisisResources({ compact = false }: { compact?: boolean }) {
  return (
    <section
      role="alert"
      aria-labelledby="crisis-title"
      className="rounded-2xl border border-destructive/30 bg-destructive-soft p-5 sm:p-6"
    >
      <div className="flex items-start gap-3">
        <HeartHandshake className="mt-0.5 size-6 shrink-0 text-destructive" aria-hidden />
        <div className="space-y-2">
          <h2 id="crisis-title" className="text-lg font-semibold">You don't have to face this alone</h2>
          {!compact && (
            <p className="text-sm leading-relaxed text-foreground/80">
              You mentioned having thoughts of being better off dead or hurting yourself. These thoughts can be
              painful, and support is available right now — free, confidential, and 24/7.
            </p>
          )}
        </div>
      </div>
      <div className="mt-4 grid gap-2 sm:grid-cols-3">
        <Button asChild variant="destructive" size="lg" className="h-12">
          <a href="tel:988"><Phone aria-hidden /> Call 988</a>
        </Button>
        <Button asChild variant="outline" size="lg" className="h-12 bg-card">
          <a href="sms:988"><MessageSquare aria-hidden /> Text 988</a>
        </Button>
        <Button asChild variant="outline" size="lg" className="h-12 bg-card">
          <a href="tel:911"><Siren aria-hidden /> Emergency: 911</a>
        </Button>
      </div>
      <p className="mt-3 text-xs text-foreground/70">
        988 Suicide &amp; Crisis Lifeline (US). If you are in immediate danger, call 911 or go to the nearest
        emergency department. Outside the US, contact your local emergency number.
      </p>
    </section>
  );
}
